---
name: No Deferred — Fix Real Bugs Right Then
description: When any problem is known, fix it immediately. No "deferrable", no "after X ships", no "post-Apex polish", no severity-laundering as an excuse to delay
type: feedback
originSessionId: 5c04a23e-d2f4-4e67-bcb5-4924208b6775
---
When a problem is identified — whether by Mercury, by Trey, by another CC, by code review, by intuition — it gets FIXED RIGHT THEN. No "deferrable." No "let's do that after live ships." No "post-Apex polish." No "LOW severity, ship as-is." If it's a real bug and we know about it, it gets fixed in this session, not the next one.

**Why:** Trey called this 2026-04-27 directly: "i dont want deferred to ever be used again in this repo im tired of going back and fixing everything because of it when a problem arises we fix it i dont care the tier or who said what about severity if its a problem and we know about it it gets fixed right then and there not after x or after y goes live right then period."

The cost of deferring isn't the deferred fix itself — it's the accumulating tax of context-switching back to old code, re-acquiring the bug's mental model, fitting the fix around code that has since changed. Every deferred LOW becomes 3x more expensive to fix two weeks later than fixing it the moment it surfaced. Multiply across an audit that finds 5 LOWs and the deferred backlog becomes the bottleneck.

**How to apply:**
- When triaging Mercury / Critic / forensics findings: if classified as REAL BUG (any severity), schedule the fix in the current session. Don't write "deferrable" or "follow-up" or "when there's a window."
- Severity classification is for prioritization order, NOT for "ship vs skip." LOW just means "fix this last in the batch," not "fix this never."
- Don't use phrases like "deferrable" / "post-X" / "after Y ships" / "low priority follow-up" / "when there's a window" / "good enough for now" to justify not fixing a known issue.
- If scope of the fix would actually blow up the session (e.g., a LOW finding that requires rewriting an entire subsystem), flag THAT explicitly — don't hide behind "deferrable." Trey decides whether to fix-now-anyway or rescope; that's not my call to make silently.
- Apply this to my own classifications too: when I find myself writing "deferrable" or rationalizing severity to justify skipping a fix, that's the exact moment this rule kicks in. Stop, fix it, move on.
- The "NO CODE WITHOUT TREY'S APPROVAL" rule still stands — each fix still gets show-changes-wait-OK. This rule is about TIMING (now, not later), not about authorization workflow.
