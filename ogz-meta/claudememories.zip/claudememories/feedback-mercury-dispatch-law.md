---
name: Mercury dispatch law — 60 iterations, 7750 tokens, Mercury-is-almost-always-right
description: Mercury dispatch params: --max-iterations=60 (up from 30/31 default), --max-tokens=7750 always. If Mercury returns wrong-looking output, the cause is almost always MY prompt, not Mercury hallucinating — Mercury crawls code before hallucinating. If prompt is too long, chunk it.
type: feedback
originSessionId: a19c960d-8a89-41b1-8c1f-9d8a49816075
---
When dispatching Mercury via `trai_brain/mercury-bridge/ask.js` or `react-loop.js`:

**Dispatch params (current canonical):**
- `--max-iterations=60` — up from the prior default of 30/31. Mercury needs the headroom for adversarial code crawls. Cap-bumping below 60 silently truncates investigation.
- `--max-tokens=7750` — never lower. Cap-truncation silently drops tasks from multi-task audits (per `feedback-mercury-max-tokens.md`).
- File:line ranges in every prompt (per `feedback-mercury-exact-line-ranges.md`).
- Attack framing always (per `feedback-mercury-attack-not-verify.md`).
- One audit at a time (per `feedback-mercury-one-at-a-time.md`).

**Core principle: Mercury is almost always right.** Mercury crawls code before hallucinating — its tool-calling loop actively reads files via the bridge before generating responses. So when Mercury returns output that looks wrong, the diagnosis order is:

1. **My prompt was wrong or under-specified** — most common cause. Missing file:line ranges, soft framing, ambiguous scope.
2. **My prompt was too long** — chunk it. Break a single multi-target audit into N sequential single-target audits.
3. **Mercury actually hallucinated** — rare. Only conclude this AFTER auditing the prompt for issues 1 and 2.

**Why:** Mercury is the verification layer. If I doubt Mercury by default, the cognition stack collapses — every call becomes a manual code re-read which defeats the purpose of having Mercury. Trey ratified this 2026-05-11: "mercury is almost always right he crawls code before hallucination."

**How to apply:**
- Before declaring a Mercury finding "wrong" or "false positive," re-read MY prompt. Did I name the exact lines? Did I attack-frame? Did I overload it with multiple targets?
- If the prompt is >150 lines or covers >3 distinct concerns, chunk before dispatching. Each chunk gets its own ask + checkpoint.
- When Mercury contradicts my mental model, my mental model is the first suspect, not Mercury's output.
- Never lower iterations below 60 to "save tokens" — Mercury underrun = bad audit.

**Pre-dispatch checklist (every time):**
0. **ONE question per dispatch** — not N bundled with "find any of the following." If audit has N vectors, dispatch N times sequentially. Per `feedback-mercury-one-at-a-time.md`.
1. file:line ranges named? 
2. attack framing (find/construct/exploit, not "is it correct?")? 
3. scope contained (one bug class or one file region, not "audit everything")?
4. --max-iterations=60 set?
5. --max-tokens=7750 set?
6. prompt length checked — chunked if >150 lines?
7. dispatch invocation logged to `.cmd` sibling file alongside prompt + response so flags are recoverable?

**Adopted:** 2026-05-11 after Trey said: "when pinging mercry up the iterations to 60 with 7750 tokens and if it comes back wrong its usually a prompt error mercury is almost always right he crawls code before hallucination so and if its too long break ti up int chunks for mercuyry."
