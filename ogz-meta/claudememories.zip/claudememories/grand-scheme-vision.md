---
name: OGZPrime Grand Scheme — the North Star
description: Apex → Houston → TRAI moat → white-glove licensing. Every architectural decision should point at this.
type: project
originSessionId: 178e5620-a10e-4916-93d4-a046460eeb3c
---
OGZPrime is NOT "another algo bot." It's three integrated layers: (1) multi-broker/multi-asset/multi-direction/multi-timeframe trading engine, (2) cross-broker arbitrage engine, (3) TRAI — autonomous AI brain handling news/whale-watching/pattern modulation/customer service/boomer onboarding/content generation/ops management.

**Why:** Trading engine is commodity. TRAI is the moat — no competitor has an AI brain that runs the bot, handles customer support, and generates content off the same model. White-glove licensing to fintech companies is the preferred monetization (Trey stays engineer/royalty collector, licensee handles their customer side).

**Phased monetization (canonical in `ogz-meta/GRAND-SCHEME.md`):**
1. Apex evaluation extraction — 20 accounts × $25K = $500K working capital. Single account passing = $25K = Houston move to be with Annamarie (daughter, 6 years estranged, 4 hours away).
2. Crypto arbitrage (90% built, paused — fees solved by 0%-maker tiers, backtests solved 2026-04-07).
3. Options layer via Tastyworks.
4. White-glove public release.
5. Sell or collect royalties.

**How to apply:** Before proposing ANY new module/feature/refactor, ask: does this advance Apex extraction, TRAI buildout, or asset-class expansion? If it's a sideways nice-to-have, push back — we're erasing things not building things right now. Tail risk math matters: Apex tuning targets worst-case across 20 simultaneous accounts, not best-case on one. 12% return with 3% drawdown beats 20% return with 8% drawdown. Every doc decision should reference the north star, not invent new ones.
