---
name: Mercury Dispatch Playbook — how to recover when agentic choke happens
description: Three failure modes for Mercury agentic calls, each with a distinct fix. Don't conflate them.
type: feedback
originSessionId: 178e5620-a10e-4916-93d4-a046460eeb3c
---
Mercury agentic ReAct (`node trai_brain/mercury-bridge/ask.js --agentic --max-iterations=N "..."`) has three distinct failure modes. Apply the correct fix per mode:

**1. `termination: max_iterations`** — Mercury used all N tool-call rounds without producing a final answer. Fix: **bump `--max-iterations`**. Trey's observation 2026-04-20: typical Mercury usage is in the 30s range, he's seen it run to 60. Start at 30 for focused single-claim work, bump to 60 when verifying multi-claim batches. Don't split prematurely.

**2. `termination: error` with `HTTP 429 input_token_limit`** — message history (prompt + accumulated tool results) exceeded Mercury-2's input cap mid-run. Fix: **split the prompt into smaller batches**, not more iterations. Each batch starts fresh with clean context. Rule: ≤5 claims per batch if claims require heavy grep/read; single claim per batch if it requires wide codebase enumeration.

**3. `CANNOT VERIFY` on all claims** — Mercury's tools (grep, open_file, get_chunk, list_files) failed to access the data source (e.g., 720 MB JSONL file outside the indexed corpus, binary files, files too large to stream). Fix: **do the enumeration directly with bash/python streaming tools** — same evidence quality since the work is mechanical pattern matching, not reasoning. Cite file:line the same way Mercury would.

**Why:** Don't pay Mercury rate-limit / API cost to retry the wrong way. `max_iterations` and `429` both look like "Mercury choked" but demand opposite responses (more iterations vs less prompt). `CANNOT VERIFY` is Mercury saying "I don't have the tool for this" — answer it yourself.

**How to apply:** When a Mercury call returns without a usable answer, read the `[iterations: N | termination: X]` footer first. Pick the fix for that specific termination mode. If you're doing pure enumeration (grep counts, null-field scans, schema key diffs), consider skipping Mercury entirely — direct bash is often faster and cleaner for mechanical tasks, matching the "verify with code" rule.
