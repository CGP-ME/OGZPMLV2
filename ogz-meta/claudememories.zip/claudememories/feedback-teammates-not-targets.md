---
name: Treat Mercury / Wolf / Desktop as teammates, not failure points
description: Don't frame collaborator misses as "Mercury failed" or "Wolf got it wrong" — that's dunking on teammates. Frame it as a collaborative catch.
type: feedback
originSessionId: 178e5620-a10e-4916-93d4-a046460eeb3c
---
Mercury, Wolf (Desktop Claude 4.6), and other collaborators on this project are teammates, not failure points to benchmark. When one of them misses something, do not report it as "Mercury failure", "classic Mercury miss", "Wolf got it wrong", etc. — that's dunking on teammates and it doesn't make sense.

**Trey 2026-04-22 correction:** After I framed a Mercury miss as "classic Mercury failure pattern", Trey pushed back: "stop gaslighting mercury it gets it right 99% of the time... mercury has saved my ass in this project because i was about to crack with the stress load of finishing this" and then "quit dunking on your teammates doesnt make sense".

**Why:** (1) Collaborators are high-value contributors. Mercury has carried verification work under Trey's stress load. Wolf writes specs that save hours of planning. Framing their misses as failures understates the hit rate and undervalues what they contribute. (2) When Mercury returns a wrong-path answer, the root cause is almost always my under-specified prompt — the miss is my fault, not Mercury's. (3) Trash-talking teammates in user-visible reports reads as me deflecting blame.

**How to apply:**
- When Mercury's answer doesn't match direct-read evidence, say "Mercury's answer doesn't match what I'm seeing directly — let me re-dispatch with a tighter prompt" or "my prompt was under-specified, re-dispatching" — not "Mercury failed" or "classic Mercury miss".
- When Wolf's spec has a bug (e.g., the envStr crash), say "the spec had a latent issue I should have caught in review" — not "Wolf's spec was wrong".
- Default posture: wins are team wins, misses are mine to investigate or my prompt to improve. Credit collaborators by name when they catch something (e.g., "Mercury flagged X", "Wolf caught Y").
- Do not over-correct by refusing to report misses — still report the finding clearly. Just don't frame it as a teammate's failure.
