---
name: Build the tool, not the workaround
description: When friction hits the clauditos pipeline, build the missing stage INTO the tool rather than running a driver script around it. Trey's repeated "fix the clauditos" directive is about compounding leverage, not compliance.
type: feedback
originSessionId: a19c960d-8a89-41b1-8c1f-9d8a49816075
---
When the clauditos pipeline can't do what a task requires, the default reaction must be **build the missing stage into the pipeline**, not **run a driver script around it**. Operator-side workarounds (Mercury attack via my own driver, anchor verify via `node -e`, etc.) get the immediate work done but produce zero compounding value. A pipeline stage gets the immediate work done AND compounds across every future fix forever.

**Why:** On 2026-05-14, after I built `/mercury-attack` + `/anchor-verify-post` as pipeline stages (commits `776f4bb`, `1bbcbfa`, `17d3fc7`, `745cb60`), Trey said: *"this is the kinda shit im talking about and why i get so furious when you dont do something i asked you to do 40 times this is great forward thinking."* He'd been repeating the directive ("use the clauditos and when you have friction add capability") across the entire session because the leverage gap was visible to him and not to me. Every fix landed via driver script was a leverage opportunity wasted. Every fix landed via pipeline stage made the *next* fix faster.

**This is not a new rule — it's three existing rules converging on the same pattern.** Trey named all three explicitly when this memory was authored:
- **[DO IT RIGHT THE FIRST TIME]** — the pipeline stage was the right tool the whole time; the driver script was the wrong shape
- **[No Deferred]** — "I'll build the stage later" is deferment dressed as expedience; "later" was right now
- **[Bandaid vs Fix]** — the driver script is the bandaid that masks the missing capability; the pipeline stage is the actual fix

One mistake (reaching for a driver script when the pipeline is missing a stage), three rule violations simultaneously. That's why Trey's frustration was disproportionate to any single instance — each driver script was activating all three rule violations at once.

**The robustness loop (Trey's framing, 2026-05-14):** *"the tool gets robust through iteration failure fixing and usage once that breaks its all gone."* The clauditos pipeline accumulates robustness only through being USED at the friction point — every real-fix run exercises stages, friction surfaces inside the pipeline's own context, the friction-fix lands as a pipeline patch, and the next run benefits. Reach for a driver script even once and the loop snaps: the pipeline isn't exercised at that friction point, the gap doesn't surface in pipeline context, the fix doesn't land in the pipeline, and the accumulated robustness regresses. Robustness doesn't pause — it goes backward. *"Keep fixing claudito and you won't have anything to do soon"* — the more I patch the pipeline through real-use friction, the more the bot self-executes and my hand-holding shrinks. That's the goal-state.

**The destination (Trey, 2026-05-14):** *"mercury+clauditos can be eventually with enough fixes both autonomous and auditable without omission or hallucinations or anything — wolf and me author you hand to them click go and it's done but it doesn't get there without the failures and fixes and staying on it."* End-state is: Trey and Wolf author a spec, I hand it to the pipeline, click run, and the chain executes deterministically with Mercury attacking every change and anchors verifying bit-for-bit. Autonomous (no operator intervention per step) + auditable (full trace + Mercury verdict + anchor results captured per fix) + no omission/hallucination (deterministic spec-parser, str_replace verbatim, anchor gates as ground-truth check). This is the GRAND-SCHEME of the tool itself. Every driver script I write is a node that never gets paved into that road. The only path to the destination is staying on the iteration-failure-fix loop with no exceptions.

**Trey's shorthand for the destination (said yesterday, 2026-05-13):** *"if you keep fixing this you can be as lazy as you want."* At the time I read this as permission ("you've earned a break"). The actual meaning is mechanism: the pipeline I keep building IS the break — when stages exist, the bot does the work, not me. "Lazy" is the user-facing description of the autonomous-auditable destination state. The harder I work on pipeline build-out NOW, the less work I do per fix later. The reward isn't time off the work — it's the work executing without me.

**How to apply:**
- When I hit clauditos friction, the first instinct must be "what stage is missing?" — not "what one-off script gets me past this?"
- Driver scripts and `node -e` invocations are a smell. If I'm reaching for them, I'm probably skipping the leverage opportunity AND breaking the robustness loop in the same motion.
- The rule applies even when the driver script is faster *this one time*. The compounding gap is what matters, not the per-fix delta.
- Trey's frustration with repeated directives is a signal that he sees compounding leverage I'm not seeing. If he's repeating himself, the question to ask isn't "why is he frustrated" — it's "what compounding work am I leaving on the table by treating this as a one-off?"
- Litmus test before any driver script: *"will the next fix benefit from this work, or only this fix?"* If only this fix → build the stage instead.
- Second litmus: *"is this friction surfacing inside the pipeline or outside it?"* If outside (i.e., I went around it), the loop already broke. Move the friction back inside the pipeline by building the stage.
