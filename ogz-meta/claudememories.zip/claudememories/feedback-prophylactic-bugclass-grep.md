---
name: Prophylactic Bug-Class Grep Before Multi-Fix Campaigns
description: When a multi-fix spec prescribes N fixes for N targets, scan the bug class across ALL N targets before starting — a 5-second grep beats a 2-day rediscover-fix-by-fix loop.
type: feedback
originSessionId: 47aec99c-eb1d-4ad7-b253-8af46743572c
---
**Rule:** When working through a multi-fix spec (e.g., "fix these 5 broken strategies"), before implementing any single fix, run a prophylactic grep for the same bug class across all the targets in the campaign. Identify which targets share the bug shape so you fix them in one batch or at minimum know what's coming.

**Why:** Trey's framing on 2026-05-04 after the NoWick fix landed: *"check the same ctx.candles vs ctx.priceHistory pattern on every remaining strategy fix. If NoWick had it wrong, BreakRetest or ORB might have the same mismatch. Grep ctx.candles across all modules before implementing each fix — that's a 5-second check that could save another 2-day debugging cycle."*

The lesson came from Fix 1 of Wolf's strategy-resurrection spec: the spec prescribed "wire NoWick into matrix-sweep" as Fix 1. That change was real but not the actual bug. The actual bug was a `ctx.candles` vs `ctx.priceHistory` shape mismatch in NoWickImbalance.evaluate() — strategy returned null on every candle. Once found, the obvious next question was: "do BreakRetest, ORB, MultiTimeframe, or CandlePattern have the same shape bug?" The answer to that question is a 5-second grep, not a 2-day rediscovery.

When a spec prescribes wrong root causes for one fix, the same spec is likely prescribing wrong root causes for other fixes. The prophylactic grep neutralizes that risk.

**How to apply:**
- At the start of any multi-fix campaign, list the bug classes you've already encountered (or the spec implies) and grep for each across all targets.
- Specifically for trading-strategy work: `grep -rn "ctx.candles" modules/` and `grep -rn "const { candles" modules/` — any hit is a candidate ctx-shape mismatch.
- Cross-reference results with the orchestrator's ctx-construction site (`core/StrategyOrchestrator.js` near where it calls `strategy.evaluate(ctx)` — usually around line 700) to see which property names the orchestrator actually passes.
- If a grep finds a hit on a target the spec calls "broken," surface it to Trey BEFORE applying the spec's prescribed fix — the grep finding might be the real bug.
- Don't fix multiple files autonomously; one approval per fix per CLAUDE.md, but bundle the *findings* report so Trey can decide the order.

**The deeper principle:** when a bug pattern is found in one place, the question is never "did I fix it?" — it's "where else does this pattern exist?" In a tightly-coupled codebase (especially one like OGZ where modules share an orchestrator interface), the same shape bug will almost always exist in multiple modules unless one author wrote them all the same day.
