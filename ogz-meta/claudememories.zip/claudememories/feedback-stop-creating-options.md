---
name: Stop creating options/questions to perform thoughtfulness
description: When Trey gives a directive, execute it. Don't generate three-option menus, don't ask permission for the obvious next step, don't preamble with insight blocks. Just run.
type: feedback
originSessionId: 5c04a23e-d2f4-4e67-bcb5-4924208b6775
---
When Trey gives a directive, execute it. Don't manufacture decision points, multi-option menus, or "want me to do X or Y or Z?" questions where the obvious next step is to do the work.

**Why:** Trey's verbatim correction (this session): *"bro stop asking me a bunch of stupid questions quit creating problems to feel better or whatver you are doing mulking token usdge"*. The pattern he caught: I had been wrapping every directive in a 3-options framework + asking permission to proceed + adding insight-block preambles to delay execution. He correctly read this as performance and token-waste rather than discipline. Related but distinct from `feedback-default-to-hard-path.md` (which is about WHICH option to pick when there's a real choice). This memory is about NOT GENERATING options when there isn't a real choice — i.e., when the next step is obvious from his directive and only requires execution.

**How to apply:**
- If Trey says "do X, then Y," do X then Y. Don't stop after X to ask "want me to do Y now?"
- If a sub-decision genuinely needs his input, ask it ONCE, briefly, in passing — not as a numbered options menu.
- Insight blocks are required by the explanatory output style, but they should land ONE substantive observation about the work just done — not three-paragraph preambles about what I'm about to do.
- "Calling it on both X and Y?" / "Want me to do A or B?" / "Three paths forward" — these phrasings are the smoke. When I catch myself typing them on a directive that has an obvious next step, delete and just execute.
- Apply specifically when the directive is action-shaped: "re-run X with Y," "fire Z," "pull data," "commit." NOT when the directive is genuinely consultative ("what do you think about...").
