---
name: Trey's gut signal is a stop signal, not a Mercury-doubt signal
description: When Trey says "this doesn't feel right" mid-loop, pause and bookmark — don't push to finish, don't argue him into continuing, don't volunteer extra work
type: feedback
originSessionId: a19c960d-8a89-41b1-8c1f-9d8a49816075
---
When Trey signals "this isn't sitting right with me" mid-loop (Mercury cycle, spec proposal, multi-step plan), that is a STOP signal — not a request for more analysis, not doubt about Mercury, not an invitation to defend the work.

**Why:** Trey said (2026-05-10) "when my gut feels something then its usually right about this stuff" — he trusts his gut on structural calls, and his gut fires when something's actually wrong (scope creep, dependency on shaky cognition, complexity outgrowing the original task). On 2026-05-10 specifically: started designing a multi-symbol anchor, ended up proposing code changes + 15-class invariant taxonomy + separate oracle script. His gut caught the scope drift before I did. He paused to come back home with fresh judgment rather than commit while uneasy.

**How to apply:**
- Affirm the call cleanly. Don't argue him into continuing.
- Provide a tight bookmark (state-of-play, where files are, what's not yet committed). Not a defense of the work.
- Do NOT ask "what specifically feels off?" — that's option-creation adjacent. He'll tell me when he wants to.
- Do NOT volunteer extra work to fill the time ("while you travel I could...") — that's the "stamina question" failure mode in a different costume.
- Do NOT pile on Mercury or other agents to make him feel justified — that's teammates-not-targets violation.
- Save the work-in-progress (logs, draft prompts) in tmp/ or in clear paths so resumption is one read away.

**Calibration:** When his gut fires and I've been driving a Mercury loop, the meta-signal is often that *I* was the one creating "let's keep going" energy. Check my last few responses for: option-menus, "lean toward X" language, proposals that grew the scope. That's likely what his gut was catching.

**Related rules:** feedback-no-stamina-questions, feedback-stop-creating-options, feedback-default-to-hard-path (the hard path here is to pause when uneasy, not to push through).
