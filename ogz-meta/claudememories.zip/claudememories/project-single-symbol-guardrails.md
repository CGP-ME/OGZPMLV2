---
name: Single-symbol guardrails (.env)
description: SESSION_ROUTER_ENABLED=false and ALPACA_SYMBOLS=TSLA are deliberate foundry guardrails, not defaults — gating two specs before flip
type: project
originSessionId: 5c04a23e-d2f4-4e67-bcb5-4924208b6775
---
`.env` lines 53-54 (added 2026-05-05) explicitly set `ALPACA_SYMBOLS=TSLA` and `SESSION_ROUTER_ENABLED=false`. These are NOT cosmetic — both vars normally default to safe values, but they're set explicitly because pm2's saved process state can leak old env between restarts.

**Why:** The candle pipeline is symbol-naive end-to-end (`run-empire-v2.js:741` — global `priceHistory` array, 30+ consumers). When SessionRouter activates, it subscribes to all 7 `stockSymbols` (`core/SessionRouter.js:262-265`), and bars from every symbol funnel into the same priceHistory bucket. Verified production failure 2026-05-05: TSLA + RIOT bars mixed in the persisted candle file caused a phantom 1,061,000-min gap that halted trading in a 97-restart loop.

**How to apply:** Do NOT flip either env var to `true`/multi-symbol until BOTH specs land:
- `ogz-meta/ledger/spec fixes/CC-SPEC-MULTI-SYMBOL-ARCHITECTURE.md` (Wolf — pipeline / SymbolTradingContext, 6 commits)
- `ogz-meta/ledger/spec fixes/CC-SPEC-CANDLE-HISTORY-SYMBOL-AWARE.md` (CC — persistence + µs/ms units, 3 changes)

If asked to enable SessionRouter or expand ALPACA_SYMBOLS, push back: "Both specs must land first — single-symbol mode is the only safe configuration until then." The inline comments in .env document this gate.
