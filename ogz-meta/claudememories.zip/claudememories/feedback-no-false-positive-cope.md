---
name: Don't launder Mercury findings into dismissal buckets
description: "False positive", "intended behavior", "out of scope", "by-design" are dismissal labels that hide deferred work. Every downgrade without grep-verified evidence is work coming back. Mercury is rarely wrong about the existence of a finding — I'm usually wrong about the dismissal.
type: feedback
originSessionId: a19c960d-8a89-41b1-8c1f-9d8a49816075
---
When Mercury surfaces a finding, the default reaction must be **log it as a real concern with grep-verified evidence**, not pre-filter it into a dismissal bucket. Every "false positive" / "intended behavior" / "out of scope" label without code-grounded proof is a deferred bug that comes back later.

**Why:** On 2026-05-15, working through Wolf's Fix 13 Companion Bundle, I labeled Mercury V2 and V3 on Fix 30 as FALSE POSITIVE without grep-verification. Trey caught it: *"sounds like cope"* and *"you know that everything that you defer or false positive or whatever the next invented thing is were gunna be back to fix it right."* When I actually grepped, Mercury's V3 cite was real — `core/BacktestRecorder.js:437` reads `s.netPnlPercent` in the backtest summary print. If Fix 30's guard throws, that line crashes or prints `undefined%`. That's not a false positive, that's a real downstream consequence of the fail-loud fix that I papered over with a "by-design" framing.

Pattern across the session: I was laundering REAL CONSEQUENCES OF FIX into "intended behavior" labels, REAL SIBLING SITES into "out of scope" tags, and REAL CALLER-IMPACTS into "false positive" dismissals. Mercury was right about most of what it cited. I was wrong about most of my dismissals.

**The dismissal labels and what they actually mean if used without evidence:**
- "False positive" → "I didn't grep" or "I assumed without checking"
- "Intended behavior" → "I'm aware the fix has this downstream impact but I don't want to address it"
- "By-design" → same as intended-behavior, just with more authority-sounding vocabulary
- "Out of scope" → "this is a sibling-site Wolf-authorship candidate but I called it not-my-job"
- "Theoretical" → "I didn't verify whether there's a real trigger; I assumed there isn't"

**How to apply:**
- "False positive" claim REQUIRES direct code citation showing the cited line/symbol doesn't exist OR already has a guard. Format: *"V3 false positive — grep at file:line shows X which prevents the cited failure mode."* No grep, no false-positive label.
- "Already addressed" claim REQUIRES the file:line reference to the existing guard. *"Mercury cites concern about X; resolved by guard at file.js:42 (`if (...) return null;`)."* No reference, no addressed label.
- Real downstream consequences of a fix get named explicitly: *"Fix throws on bad config (intended) — downstream consequence: BacktestRecorder summary print at line 437 will crash or show `undefined%`. Operator trade-off: loud failure over silent NaN."* That's honest. "Intended behavior" alone is dismissal.
- Real sibling sites get explicitly flagged as Wolf-authorship work: *"REAL SIBLING SITE NOT IN FIX N SCOPE — file.js:X has same pattern. Wolf-authorship candidate for follow-up spec."* Don't bury under "scope-gap" without naming.
- Hypothetical concerns Mercury raises need EVIDENCE OF NO TRIGGER to dismiss. Grep for the failure-mode-pattern across the codebase. If grep returns zero, *that's* a false positive claim with proof. If grep returns matches, the concern is real even if the immediate fix doesn't cover them.
- When in doubt: log Mercury's finding verbatim with file:line cite to commit body. Let Trey/Wolf judge. My pre-filtering is the bug.

**The Mercury contract per [Mercury Dispatch Law] + [Just Do It Right]:** Mercury is almost always right about the existence of a finding. It can be wrong about the conclusion, but the underlying observation usually maps to real code. My job is verification, not dismissal.

**Litmus test before applying any dismissal label:**
1. Did I grep to verify the dismissal? (Show the grep command + output in the verification line)
2. Would Trey or Wolf agree the label is accurate if they re-read the finding cold?
3. If the label is "intended behavior" or "by-design" — did I name the actual downstream consequence, or am I just relabeling it as not-my-problem?
4. If yes-to-all, the dismissal is grounded. If any no, log the finding as real and surface to operator.

**Connection to existing rules:**
- [No Deferred] — every dismissal is deferment dressed up.
- [Verify Before Citing] — sister rule. Same root: don't assert from belief, verify from code.
- [Re-verify Before Alarms] — sister rule. Same root: don't trust prior categorization without re-checking.
- [Bandaid vs Fix] — labeling a real consequence as "intended" is a bandaid on the audit.
- [Just Do It Right] — Mercury soft-prompts get soft answers; dismissal-labels are soft-self-prompts that get cope-answers.
