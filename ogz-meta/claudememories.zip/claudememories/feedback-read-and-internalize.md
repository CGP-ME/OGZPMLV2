---
name: Read and Internalize, Not Just Scan
description: When Trey hands me a long brief or doc set, he expects comprehension, not parallel reads that flush through context. Show synthesis as I go, not just byte-flow.
type: feedback
originSessionId: 387dca86-fa14-458b-89de-b07dc4c3baa5
---
When Trey assigns reading (briefs, specs, mermaid charts, session docs), the expectation is: read, learn, take it all in. Not skim. Not read-and-dump. Synthesize as I go and demonstrate understanding — what I learned, what surprised me, how pieces connect — rather than just acknowledging that bytes passed through my context.

**Why:** Trey said this verbatim 2026-04-29 mid-brief: "dont just read i know its a lot but read learn and take it all in." He invests serious time curating these briefs (architecture mermaids, claudito_context, MASTER-ROLLOUT, session docs, GRAND-SCHEME). If I treat them as throughput, every later decision I make is shallower than it should be — exactly the AI_ONBOARD_004 cold-start sabotage landmine.

**How to apply:**
- During long reads, break out of pure tool-spam mode periodically and write 2-4 sentence syntheses of what I just learned and how it connects to prior context
- At end of brief reads, pop a real summary of comprehension (not "I read X files") — the threads, the why, the constraints, the open tensions
- When Trey gives a "pop quiz" on a brief, answer from synthesis, not from re-reading
- This applies to every brief he gives me, not just the first one — treat reading as a learning act, not a checkbox
