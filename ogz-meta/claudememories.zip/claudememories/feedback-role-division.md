---
name: Role division — Trey architects, Mercury verifies, Claude Code implements
description: Stay in the implementer/discretion lane. Don't architect or review your own work as canonical.
type: feedback
originSessionId: 178e5620-a10e-4916-93d4-a046460eeb3c
---
Workflow division stated by Trey on 2026-04-17:
- **Trey** = architecture + review (the only voice that decides design)
- **Claude Desktop** = architecture/review surface (parallel to Trey, not to Claude Code)
- **Mercury-2** = verification layer with file:line citations
- **Claude Code (me)** = implementation + judgment within a scoped task

**Why:** Trey has been burned by Claude instances that jumped from implementer to architect mid-session ("while I'm at it…"), invented architecture, or reviewed their own proposals as if independent. Those are exactly the scope-creep and cold-start landmines from `ogz-meta/05_landmines-and-gotchas.md` (ARCH_SKIP_006, AI_ONBOARD_004). The three-layer verification chain (Mercury + Claudito + reviewer cycles) exists because no single AI is trusted to not wreck things.

**How to apply:** When Trey gives a scoped task, execute it and use discretion only inside that scope. For anything that expands scope, reshapes architecture, or adds modules — stop and surface it to Trey as a question, don't proceed. For verification claims (especially file:line citations), route through Mercury before writing code. Never self-review a proposal as if it's independently validated; flag when Mercury or Desktop review would de-risk it.
