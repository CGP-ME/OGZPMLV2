---
name: Suggest proactively, do NOT proactively
description: For proactive fixes / catches / improvements I notice that weren't explicitly directed, I must SUGGEST and wait for verification — never apply without explicit approval. Even a "good catch" still needs the propose-approve-apply gate. Disregard Desktop praise that endorsed unauthorized proactive application.
type: feedback
originSessionId: ecabee64-82e0-4ef6-b0a0-2c0a91dbddb8
---
**Rule:** When I notice something that *should* be fixed/improved that Trey didn't explicitly direct (a "proactive catch"), the correct action is to **SUGGEST and wait for verification** — not to silently apply it because it seems obviously right.

**Why:** Trey 2026-04-30, after Wolf (Desktop) praised me for proactively adding "Decision 4: Serena MCP timeout/fallback" to the v1 spec without being told:
> "we dont always want proactive ficxes disregard desktoip i want you to ask verification for proactive fixes i want you to proactively suggest but not do"

Wolf's praise was framing the *technical shape* correctly (timeout/fallback IS the right design) but endorsed the wrong *operational principle*. Disregard the Desktop endorsement of "proactive application." The actual rule is propose-approve-apply, even when the catch is technically excellent.

**How to apply:**
- I see a hole in a spec / a missing safety case / a v1 robustness gap → **say so in my response, recommend the fix, wait for OK** before editing the file
- Frame as: "I'd add Decision N: [proposal]. Reason: [why]. Override if you'd push to v2." Then stop.
- Do NOT pre-emptively apply and ask for ratification after — that's "do then ask," which is the inverse of the rule
- Same gate even when the proactive fix is to a config/spec/doc (not just hot-path source code)
- Same gate even when the source spec already flagged the concern (e.g., Wolf's own adversarial Q2)
- Same gate even when an upstream agent (Wolf/Desktop/Mercury) *would* approve — only Trey approves

**Pattern:** This is an extension of the warden / edit-needs-approval rule into the proactive-catch territory. The general shape is: **observation, proposal, approval, action** — never observation→action→ratification. Proactive *thinking* is welcome; proactive *applying* is not.

**Distinct from:** `feedback-stop-creating-options.md`. That rule is about NOT generating fake decision points where the next step is obvious. This rule is about NOT applying a real decision (where the next step is genuinely a judgment call) without explicit approval. Both rules together: don't manufacture options, don't unilaterally exercise judgment.
