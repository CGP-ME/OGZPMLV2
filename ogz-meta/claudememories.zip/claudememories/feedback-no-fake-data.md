---
name: No Fake Data Ever
description: Never add UI elements that show data from a source they don't claim to be — no stock tickers without stock data, no simulated values presented as real
type: feedback
---

Never add frontend options (dropdowns, buttons, displays) that imply data from a source that isn't wired. Adding stock tickers to the asset dropdown while only Kraken crypto is connected means selecting TSLA shows BTC prices — that's fake data disguised as real.

**Why:** Trey has a zero-tolerance policy on fake data. The product's entire value proposition is transparency over hype. "We've made the mistakes so you don't have to" doesn't work if the dashboard lies about what it's showing. This was explicitly hashed out and violated again.

**How to apply:** Before adding any data display element, verify the backend data source exists and is wired. If it's not wired yet, the UI element doesn't ship. No "placeholder" data, no "coming soon" displays that show wrong numbers. Empty is better than fake.
