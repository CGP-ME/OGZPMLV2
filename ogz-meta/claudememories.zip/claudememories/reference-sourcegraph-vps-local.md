---
name: Sourcegraph reads VPS local filesystem, not GitHub remote
description: ogzprime.sourcegraph.app indexes /opt/ogzprime/OGZPMLV2/ directly on the VPS — git push to origin/v3 is NOT required for DeepSearch to see a file. File presence on disk is sufficient.
type: reference
originSessionId: a19c960d-8a89-41b1-8c1f-9d8a49816075
---
The `ogzprime.sourcegraph.app` tenant accesses the OGZPMLV2 codebase via VPS-local filesystem at `/opt/ogzprime/OGZPMLV2/`, NOT via a GitHub remote mirror. DeepSearch confirmed this 2026-05-11 when Trey asked about a file freshly placed in `ogz-meta/ledger/` — DeepSearch said "it's on the VPS locally."

**Implications for my workflow:**

1. When a file lands in the working tree (via WinSCP intake, my own writes, etc.), DeepSearch can see it immediately — NO git commit + push required for visibility.
2. `git push` is for REPO AUDIT TRAIL ONLY in this setup. It's a separate concern from "is the file retrievable by Sourcegraph/DeepSearch."
3. If Trey says "DeepSearch doesn't see the file," the diagnosis is filesystem state on the VPS, NOT remote sync status. Check `ls` first, not `git log`.
4. Reindex on the Sourcegraph side may still have a delay (the instance has to detect the new file), but it's not gated on GitHub sync.

**Mechanism (unconfirmed but plausible):** Either src-cli pushes from VPS to Sourcegraph Cloud, or the Sourcegraph tenant is configured with a private code host pointing at the VPS git repo (HTTPS or SSH). Doesn't matter which — the practical effect is "files on disk are visible."

**How to apply:**
- When Trey drops a file in ledger and asks me to make it visible to DeepSearch, the file is ALREADY VISIBLE — no need to argue about git push as the activation step.
- Commit + push are still appropriate for permanent record (and for `ogz-meta/specs/` paths that Mercury indexes), but framed as audit-trail not visibility-trigger.
- Never tell Trey "I'll push so DeepSearch can see it" — that's a category error. Say "file is on disk so DeepSearch already has it; pushing is for the audit trail."

**Adopted:** 2026-05-11 after Trey pushed back on my "I pushed for DeepSearch indexing" framing — he was using DeepSearch in the web UI and it confirmed the file was VPS-local, exposing my GitHub-mirror assumption.
