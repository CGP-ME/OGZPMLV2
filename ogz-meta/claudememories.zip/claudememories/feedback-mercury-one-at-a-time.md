---
name: Mercury — one question, one answer (like one commit, one change)
description: Every Mercury dispatch asks ONE question and gets ONE answer. Multiple questions bundled in one prompt = Mercury answers the easiest one, self-terminates with answer_given, and the rest go un-hunted. Sibling of one-commit-one-change.
type: feedback
originSessionId: 178e5620-a10e-4916-93d4-a046460eeb3c
---
**One Mercury dispatch = one question = one answer.** Same shape as one-commit-one-change. Two failure modes to forbid:

1. **Shell-level parallel dispatch** — `mercury & mercury`, `xargs mercury`, two terminal sessions firing at once. Original violation Trey caught.
2. **Prompt-level bundling** — one `mercury ask` invocation that asks for "any of the following 5 things." Mercury will hunt the first vector it finds, emit `answer_given`, and terminate at low iteration count. The other 4 vectors are never audited. From the response log, this is indistinguishable from a clean completion — you only know coverage was truncated by re-reading the prompt against the response.

**Why:** Trey 2026-04-22 on shell-parallel: "he will choke if you feed him all three at once do them right one at a time yall cant even get one thing right most of the time let alone 3." Two reasons there: rate limits + my track record glossing batched results.

Trey 2026-05-18 on prompt-bundling, after Fix 30 V2 attack: bundled 5 adversarial vectors into one prompt, Mercury answered vector 1 at iter 21/60 with `answer_given`, vectors 2-5 un-hunted, I consumed the partial coverage as authoritative and built a Wolf packet on it. "you did that but the response got truncated meaning you dont even have the full picture GREAT THERES ANOTHER FAILURE POINT WE HAVE TO AUDIT."

**How to apply:**
- ONE question per prompt. If the audit has N hunt vectors, dispatch N times sequentially with per-dispatch verdict checkpoint.
- Each dispatch logs its full invocation (flags + prompt path) to a `.cmd` sibling file so the dispatch shape is recoverable.
- Per-audit checkpoint with user: "Vector 1 clean (file:line evidence) — proceed to Vector 2?" Never offer "fire all N in parallel" or "ask for any of N in one prompt."
- If a prompt naturally splits with "find any of the following," that's the smell — split into N prompts.

**Applies to:** Mercury agentic audits (ReAct loop), Mercury holistic verification passes, any Mercury-backed code review. Does NOT apply to Mercury's internal ReAct iterations (those are sequential by design within one question).

**Sibling rule:** `feedback-mercury-dispatch-law.md` pre-dispatch checklist enforces this as item 0.
