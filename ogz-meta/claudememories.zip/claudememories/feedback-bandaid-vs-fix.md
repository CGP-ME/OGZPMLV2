---
name: Bandaid vs Fix — Always Frame Mercury Adversarial as Architectural
description: Mercury's tactical "does this code break?" prompts return CORRECT for both bandaids and fixes. Always include architectural "is this the right shape?" framing
type: feedback
originSessionId: 5c04a23e-d2f4-4e67-bcb5-4924208b6775
---
A bandaid is code that closes a symptom and creates a new one. A fix is code that closes the underlying mechanism so no related symptom appears.

Mercury's tactical adversarial prompts ("find a state that BREAKS this") catch bug-class divergences (race conditions, boundary attacks, edge inputs) but DO NOT catch architecture-class bandaids — because a bandaid IS correct code; it just solves the wrong layer of the problem.

**Why:** Trey called this 2026-04-28 directly when D Finding 1's fire-and-forget fix shipped. The fix closed the polling-hang but opened a new hole: alert failures became silent. Mercury had been adversarial-checked and returned 3/4 YES findings (error swallow, race, order-of-events change), which I re-classified as "intentional/by-design." That re-classification was rationalize-Mercury-away — Mercury was pointing at the visibility gap that became Trey's concern. He said: "so you did a bandaid and not a fix."

Same pattern showed up tonight in:
- Fix #1 maxPayload (0f66df5): only capped single-frame, missed cumulative flood. Token-bucket follow-up (292d2eb) is a circuit-breaker not true backpressure.
- Fix #2 dual-timestamp (803ccde): mis-framed as closing B1 Finding 2 (clock skew), but actual closure is the pre-existing line 629 filter. monoMs is additive tooling.

**How to apply:**

1. **Always include an architectural question in adversarial Mercury prompts**, not just tactical ones. Examples:
   - Tactical (insufficient): "Find a state where this fix breaks."
   - Architectural (required): "Does this fix close the underlying mechanism, or only the symptom? What new failure modes does it introduce that the prior code didn't have? Is this the right LAYER to fix it at?"

2. **Treat Mercury YES findings on a fix's adversarial check as alarm signals, not annotation footnotes.** When Mercury says "this fix changes behavior X" and I respond "intentional/by-design," that's a smell — Mercury is flagging that I'm trading one set of failure modes for another, and I should ASK whether the trade is right.

3. **Before declaring a fix "shipped," ask three questions explicitly:**
   - "What was the original failure?" (the symptom)
   - "What was the underlying mechanism?" (the root cause)
   - "Does this close the mechanism, or just block this expression of it?"
   If the answer to #3 is "blocks this expression," that's a bandaid by definition.

4. **Bandaid is a legitimate engineering choice** — sometimes the proper fix is out of scope, the symptom is the priority, or the architecture refactor is in a future phase. But it must be NAMED as a bandaid, with the proper-fix path tracked separately. Calling a bandaid a "fix" hides it from future audits.

5. **For visibility/monitoring/alerting code specifically:** the "fix" is rarely just stopping the bad behavior — it's also ensuring the bad behavior is VISIBLE if it happens. Hung alert hook? Don't just stop the hang; ensure failed alerts are loudly recorded somewhere. Lost data? Don't just retry; track lost-vs-delivered counts. Silent failures are themselves a class of bug.

This rule was learned the hard way: 3+ bandaids landed tonight before Trey caught the pattern, costing review cycles and code-revision time. Apply it preemptively.
