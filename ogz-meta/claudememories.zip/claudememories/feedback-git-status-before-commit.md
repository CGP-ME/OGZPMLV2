---
name: git status before every commit (parallel-session repos)
description: Run `git status` before `git commit` in any repo with parallel CC/Cursor/Desktop sessions. `git add` is additive — it never gives you an exclusive index.
type: feedback
originSessionId: 47aec99c-eb1d-4ad7-b253-8af46743572c
---
In repos where Trey runs multiple CC/Cursor/Desktop sessions in parallel, the index can have files staged by OTHER sessions sitting in it. `git add <file>` is additive — it adds my file to whatever's already there, it doesn't replace the index. So `git add core/CandleProcessor.js && git commit` can ship that file PLUS anything the parallel session pre-staged hours ago.

**Why:** 2026-05-06 — I committed `4a1f72e` claiming to be a 7-line NaN guard on `core/CandleProcessor.js`. The diff was actually 94/-80 across 9 files, because a parallel CC/Cursor session had pre-staged 7 production files yesterday (FeatureExtractor, OrderExecutor, PatternMemoryBank, TradeIntelligenceEngine, TradingLoop, IndicatorSnapshotDTO, run-empire-v2) that sat in the index for 7.5 hours. My commit absorbed all of them under a misleading title. Pre-commit hook warned but bypassed in non-interactive mode. Took a `git revert` + relabel + clean re-commit + force-push-of-revert to fix. **The commit message is now a documented lie in history (`4a1f72e`)**, only mitigated by the labeled revert (`9150afd`) on top.

**The two violations were:**
- **Bundled** — one commit, three concerns mashed together (my fix + parallel session's null-handling fixes + 5 other unrelated files)
- **Mislabeled** — title claimed 1-file 7-line patch, diff was 9 files. Anyone reading `git log --oneline` 6 months from now would trust the title and bisect wrong.

**How to apply:**
- Always run `git status` (or `git diff --cached`) BEFORE `git commit`. Not optional in a parallel-session repo.
- If the index has unexpected files, STOP. Either ask Trey what they are, or unstage them via `git restore --staged <file>` before committing.
- The pre-commit protected-file warning fires for `public/unified-dashboard.html`, `core/WebSocketManager.js`, `core/CandleProcessor.js`, `core/OrderExecutor.js`, `core/TradingLoop.js`. **Treat the warning as a stop sign, not a speed bump.** Don't bypass with non-interactive default — verify the staged contents match the commit title.
- For pushed mistakes: prefer `git revert` over `git reset --soft` + force push. Per [Revert First Default]. Trail stays auditable, no clones get out of sync.
- The `git add` mental model fix: `git add` ADDS to the index. To make a commit exclusive to one file, either (a) `git status` first to confirm the index is clean before `git add`, or (b) use `git commit -- core/CandleProcessor.js` (path-limited commit) to bypass the index and commit only the named file's diff.
