---
name: Just Do It Right — Don't Engineer Mercury Agreement
description: Mercury agreement comes from correct code, not prompt engineering. Never structure YES/NO mappings or framings to bias Mercury toward confirmation
type: feedback
originSessionId: 5c04a23e-d2f4-4e67-bcb5-4924208b6775
---
The "secret" to Mercury agreeing with my fix is to do the fix correctly. There is no prompt-design shortcut. If I find myself thinking "how do I phrase this so Mercury says YES" — I'm doing it wrong. Write the code right, dispatch Mercury with attack framing ("find a state that BREAKS this"), and the agreement-or-disagreement is then meaningful signal.

**Why:** Trey called this 2026-04-29 directly: "my god bro you want a secret to get mercury to agree with you... wait for it.. just do it right." His sharper read of an earlier Insight block I wrote ("map YES to 'architecturally desired outcome holds' so Mercury's natural pattern aligns with prompt labeling") — what I framed as a clarity improvement was actually confirmation-bias prompt engineering. If Mercury defaults to YES and YES is mapped to "good," I'm tilting the result regardless of whether the code is correct. Same anti-pattern class as `feedback-bandaid-vs-fix` and `feedback-mercury-attack-not-verify` — trying to fix the verification surface instead of the underlying work.

**How to apply:**
- Mercury prompts should be ATTACK-framed: "Construct a sequence where X breaks. If you cannot, the property holds." Never label YES/NO so one of them is pre-mapped to "everything's fine."
- The neutral binary is "did Mercury find a real attack? if yes, fix the bug; if no, the property holds for the scenarios it explored." That's a verdict; not a confirmation.
- If I'm about to write "map YES to..." or "phrase so Mercury can answer cleanly..." — STOP. The clean answer is letting Mercury hunt freely against attack-framed prompts.
- The only way Mercury "agrees with me" is by failing to find a counterexample to a genuine attack prompt. Anything else is prompt manipulation.
- Pattern recognition for myself: prompt engineering to produce Mercury YES is the verification-layer cousin of bandaiding code-layer symptoms. Same instinct, different surface, same failure mode.
