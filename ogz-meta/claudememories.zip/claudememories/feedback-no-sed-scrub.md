---
name: Never sed-scrub bulk changes
description: Do not use `sed -i` or similar bulk text replacement on source files. Last time it was catastrophic. Use targeted Edit tool calls even for repetitive changes.
type: feedback
originSessionId: 178e5620-a10e-4916-93d4-a046460eeb3c
---
**Rule:** Never run `sed -i` (or any shell-based bulk regex replace) on source files to make repetitive changes. This includes emoji stripping, symbol renaming, pattern substitution, whatever. Use the Edit tool with targeted old_string/new_string replacements, one change at a time.

**Why:** Trey's words verbatim on 2026-04-22: "do not sed scrub last time that was catastrophic" / "it ended up corrupting a ton of shit." A prior session used sed for bulk cleanup and corrupted many source files (likely regex interaction with string literals, escape sequences, or multi-line code structures). Required real recovery effort. Edits must be scoped and auditable — no silent bulk rewrites.

**How to apply:**
- When the task is "remove all X from the codebase" — do it file-by-file via the Edit tool, showing each change.
- When there are hundreds of instances across many files — don't do it silently. Propose the scope, ask whether to do it over multiple commits, or whether to defer entirely.
- If bulk find is needed for scoping: `grep -rn "pattern"` or Grep tool is fine (read-only). Only the replacement side is banned.
- Exception: generated/regenerated files (build outputs, indexes) are fine to bulk-rewrite — they're not source.
- Edit tool enforces uniqueness per replacement which is the guardrail against silent breakage.
