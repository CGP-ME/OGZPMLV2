---
name: No emojis anywhere
description: Strip emojis from code, comments, docs, commit messages, console logs — anywhere they appear. OGZPrime is a professional codebase, not a Discord server.
type: feedback
originSessionId: 178e5620-a10e-4916-93d4-a046460eeb3c
---
**Rule:** Anywhere you see an emoji in this repo — code, JS/TS source files, comments, console.log strings, Markdown docs, commit messages, Claude's own responses about the code — remove it or don't add it. Applies universally. Professional codebase, no emoji decoration.

**Why:** Trey's words verbatim on 2026-04-22: "this is suppposed to be professional." When run-empire-v2.js was originally written it had emojis everywhere in console output; they render as mojibake (`âŒ`, `ðŸ¤`, `ðŸ"`) under Latin-1 rendering — so they're simultaneously unprofessional AND a visual bug. Double disqualifier.

**How to apply:**
- When writing NEW code: do not add emojis to console.log, comments, commit messages, docs. Use plain ASCII labels or Unicode box-drawing (`─`, `│`, `•`) if visual separation is needed.
- When EDITING code that already has emojis: strip them in the edit. Replace with plain text (e.g., `✅ Connected` → `Connected` or `[OK] Connected`).
- When writing CHANGELOG / recent-changes / fixes.jsonl entries: no emojis.
- When writing Claude-side markdown replies to Trey: no emojis (except where needed to quote what's already in the code, e.g., showing the mojibake).
- **Insight callouts** in Explanatory style: the ★ character is NOT an emoji — it's a unicode star glyph, keep using it for insights. But don't add 💡 or 🔥 or similar pictographs.
- **Never mass-rewrite existing files** just to strip emojis unless explicitly asked — that's scope creep. Strip them opportunistically when editing for other reasons.

Verified from Trey on 2026-04-22 after he flagged `âŒ` in run-empire-v2.js console output and extended the rule from "in code" to "anywhere you see them."
