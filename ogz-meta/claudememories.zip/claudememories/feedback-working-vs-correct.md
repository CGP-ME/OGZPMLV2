---
name: "Working" and "correct" are not the same thing
description: Confirming a system is writing data, updating counters, or producing output is not the same as confirming it's doing the right thing on the right target. Always verify BOTH.
type: feedback
originSessionId: 178e5620-a10e-4916-93d4-a046460eeb3c
---
**Rule:** When auditing any system, "it's working" means TWO things must be true:
1. The mechanical behavior is happening (writes, saves, counter ticks, logs flowing)
2. The WORK is on the correct target (right file path, right asset, right scope, right destination)

Only verifying (1) without (2) is a bug-hider.

**How this broke on 2026-04-22:**
Trey asked if pattern learning was working. I reported: "File growing at expected interval, 69,052 patterns loaded, saves every 5 min — healthy." I was right about (1). I was missing (2) — the file it was saving INTO was the crypto pattern bank, and the bot had just flipped to stocks. I celebrated "pattern learning is active" as good news without checking which bucket. 35 minutes and 7 save cycles later, the crypto bank had TSLA outcomes blended in. Trey had to ask point-blank "is this saving to a non-crypto pattern bank or are we actively corrupting our crypto bank" to trigger the check I should have done unprompted.

**Trey's exact words on 2026-04-22:** "you wouldnt have even caught it the pattern bank until we went to audit it."

**How to apply:**
- Before reporting a subsystem as "healthy" / "working" / "saving", verify:
  - Write path matches expected target for current asset / mode / session
  - Scope of what's being written matches the current operational context
  - Destination isn't shared across mutually-exclusive contexts (e.g., crypto vs stock, live vs paper) unless that's explicitly intended
- When a user flips contexts (broker change, asset change, mode change), every persistent-state subsystem needs a fresh audit — not a "looks working" check.
- "File growing" + "counter ticking" + "no errors" is only the first-order check. The second-order check is "does the target match the current operation."

**Pattern:** this mistake is sibling to `feedback-verify-before-claiming.md` — both come from reporting half-verified observations as fact. The fix in both cases: inspect the thing at the level of specificity the user is actually asking about, not the level that's easiest to check.
