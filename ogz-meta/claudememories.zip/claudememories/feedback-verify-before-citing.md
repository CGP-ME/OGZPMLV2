---
name: Verify Before Citing
description: Never quote a comment, doc, or convention as authority without git blame / git log first to confirm it's still load-bearing
type: feedback
originSessionId: 178e5620-a10e-4916-93d4-a046460eeb3c
---
Before citing a comment, README line, or doc fragment as a "convention" or "documented decision," run `git blame` (or `git log`) on it to confirm:
- When was it written?
- What was the commit message — is it describing a permanent contract or a progress marker mid-refactor?
- Has the surrounding context evolved since (other work in the same area)?

**Why:** On 2026-04-25 I cited the header comment in `public/css/dashboard.css` as evidence of a "documented split" between inline base CSS and modular visual-effects CSS, and used it to justify stacking new layout CSS back into the inline `<style>` block of `unified-dashboard.html`. Trey had to push back three times before I actually `git blame`d the comment. Result: it was written 2 weeks earlier in commit `ba7b37a` titled "feat: Dashboard Integrated Extraction — modular architecture with Extra Credit visuals" — a *progress marker at the start of the extraction*, not a permanent convention. The whole point of the commit was the modular split. I was about to undo two weeks of his refactor work by re-stacking into the monolith. Trey: "this is now the second time my work is getting pushed back while you correct something."

**How to apply:** Whenever I'm about to use the phrase "the existing convention is...", "the documented pattern is...", or quote a code comment to defend a decision — `git blame` the source line first. If the comment was written during a refactor whose direction was *toward* modularity/extraction/cleanup, treat it as a progress marker (snapshot of state-at-time) not as a contract. If unsure, ask "what was the trajectory the codebase was on?" — that's usually answered by recent commit messages, not comments. Trajectory continuation is almost always the right answer; comments rot, trajectories don't.

**Cost when this fails:** Trey's clock burns while I argue from a misread. He's the one paying in time, especially on deadline-bound work like the Apex eval prep.
