---
name: Listen First — Stop Code Diving When Told It's an Env Var
description: When Trey says the code is validated and the problem is an env var, STOP reading source code and focus exclusively on env var diagnosis
type: feedback
originSessionId: 47aec99c-eb1d-4ad7-b253-8af46743572c
---
When Trey says "the code works" and "it's an env var" — BELIEVE HIM. He ran walk-forward validations. The code is proven.

**Why:** On 2026-05-01 I burned an entire session reading StrategyOrchestrator, TradingLoop, IndicatorEngine, CandleProcessor source code trying to find a bug in code Trey explicitly told me was validated and working. He told me repeatedly the problem was an env var. I kept grepping source code anyway. He fired me.

**How to apply:**
- When Trey says the code is fine, do NOT open source files to "verify"
- When he says it's an env var, compare the env vars from the working command (in BACKTEST-OPS.md) against what's actually being passed to the process
- Read BACKTEST-OPS.md and BACKTESTING_GUIDE.md FIRST — they document exactly which env vars matter
- Run the exact commands from the docs, don't improvise
- If a backtest produces 0 trades, check env vars BEFORE reading strategy code
- The backtesting docs in ogz-meta are the source of truth for how to run backtests
