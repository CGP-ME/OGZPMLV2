---
name: Append-Only Session Docs Are Canonical
description: Every session writes one dated frozen doc under ogz-meta/sessions/; do not mutate rolling docs (MASTER-ROLLOUT, RUNNING-TODO, TODO-NEXT-SESSION) to flip checkboxes
type: feedback
originSessionId: 5c04a23e-d2f4-4e67-bcb5-4924208b6775
---
Every non-trivial OGZPrime session ends by writing ONE dated, frozen, append-only session doc under `ogz-meta/sessions/session-YYYY-MM-DD[-MM-DD]-{slug}.md`. Future sessions reference the most recent 2-3 session docs as the canonical record. Future sessions DO NOT mutate the rolling docs (`ogz-meta/MASTER-ROLLOUT.md`, `RUNNING-TODO.md`, `TODO-NEXT-SESSION.md`, `POST-MATRIX-BACKLOG.md`) to flip checkboxes / scrub stale references.

**Why:** Mutation produced 14-day-stale rolling docs by 2026-04-27. Stale docs got Mercury-indexed equally with current docs — Mercury would retrieve a 14-day-old workstream description as if it were current truth and build proposals on the lie. Trey explicitly flagged this on 2026-04-27 with: "we write a new doc with all the stuff we audited and did and added this session we date it and then we dont have to worry about the old docs they can reference this one when they are checking the lists to see... every session can talk about what was accomplished that way theres referenceable docs."

**How to apply:**
- At Scribe / Recorder stage of every session, write the session doc — use the format in existing docs (`session-2026-04-25-27-asset-isolation-strategy-parity-bot-swap.md`, `session-2026-04-08-mercury-bridge-layer4.md`)
- Required sections: header (date / branch / last commit / Phase 0 baseline), What Was Done This Session (numbered, with root cause + fix per item), Smoke Tests, Files Touched table, Git Log, Half-Cooked Items Status table, Open Items for Next Session, Context for Next Session, Recorder Pipeline Disposition
- One short composite entry to `ogz-meta/recent-changes.md` linking back to the session doc
- Do NOT update MASTER-ROLLOUT phase checkboxes, do NOT cross items off RUNNING-TODO, do NOT mutate workstream statuses — those rolling docs are starter-kit context only
- The manifest at `ogz-meta/sessions/SESSION-DOC-MANIFEST.md` is the canonical reference for this pattern
- For new sessions starting up: read CLAUDE.md → most recent 2-3 session docs → MASTER-ROLLOUT 30-Second Status only → recent-changes top 50 lines. Skip the per-phase MASTER-ROLLOUT details unless cross-checked against the latest session doc
