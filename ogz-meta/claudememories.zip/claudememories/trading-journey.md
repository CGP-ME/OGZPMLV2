# OGZPrime Trading Strategy Evolution

## The Journey (Feb 21-23, 2026)
Documented in ogz-meta/ledger/contextketchup.md (18,616 lines)

### Phase 1: Foundation
- Replaced "soupy pooled confidence" with StrategyOrchestrator (winner-takes-all)
- Each strategy evaluated in isolation, best signal wins
- Switched from 1m to 15m candles (Kraken 0.52% round-trip fees kill scalping)

### Phase 2: Strategy Building (YouTube-sourced)
| Strategy | Source | Status |
|----------|--------|--------|
| MADynamicSR | Trader DNA (123 pattern) | Active, tuned |
| EMASMACrossover | Internal | Active |
| RSI | Internal | Active (thresholds need widening) |
| LiquiditySweep | Marco | Active |
| BreakAndRetest | Desi Trades | DISABLED (0 for 9, needs state machine) |
| VolumeProfile | Fabio Valentino (Chart Fanatics) | Active (chop filter) |
| EMACalibrator | Internal | Found 50/200 optimal for BTC 15m |
| AdaptiveTimeframeSelector | Internal | Future feature |

### Phase 3: Tuning Progression (Backtests)
- Run 1: 82 trades, -$122 (overtrading)
- Run 2: 43 trades, -$85 (tighter filters)
- Run 3: 25 trades, -$49 (structural stops)
- Run 4: 14 trades, -$17.86 (acceleration filter + cooldown)

### Phase 4: Key Improvements Applied
- **Structural stops**: SL below triggering MA + ATR buffer (not fixed %)
- **1:3 R:R ratio**: TP at 3x the risk distance
- **Break-even move**: When trade hits 1:1, move stop to entry
- **Acceleration filter**: Confirmation candle range > 1.2x ATR
- **Cooldown**: No re-entry for N candles after a loss

### Phase 5: Pending - Strategy Regime Filter
- See `regime-filter-spec.md` for full spec
- Split strategies into TREND vs CHOP lanes using VP market state
- NOT YET APPLIED as of 2026-03-06

## Core Philosophy
- "Story/Narrative > Strategy" (from Z's Universal Playbook)
- "No story, no trade"
- Liquidity sweeps: don't buy breakouts, wait for stop hunts
- Context (where price is relative to structure) matters more than any indicator
- Verified foundation first, then train edge with certainty
