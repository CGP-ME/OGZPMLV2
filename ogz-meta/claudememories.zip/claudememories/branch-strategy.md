---
name: Branch Strategy Update
description: broker/alpaca-integration is the current production branch — supersedes earlier tradingloop-clean-rewrite
type: project
originSessionId: 178e5620-a10e-4916-93d4-a046460eeb3c
---
`broker/alpaca-integration` is the production branch as of 2026-04-17. Trey confirmed it directly. This supersedes the earlier `tradingloop-clean-rewrite` note.

**Why:** The branch evolved past `tradingloop-clean-rewrite`. Recent commits (f7a30e1, e894672, 4a45625, 044a091) are matrix-sweep + pre-matrix work happening live on this branch.

**How to apply:** Never reference `main` or `tradingloop-clean-rewrite` as the target. All work (commits, pushes, PRs) happens on `broker/alpaca-integration`. If the user later renames or moves the production branch, re-verify with `git branch --show-current` before trusting this note.
