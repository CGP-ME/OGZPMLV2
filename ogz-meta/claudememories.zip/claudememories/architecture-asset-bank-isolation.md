---
name: Asset-class pattern banks must be isolated
description: UnifiedPatternMemory, decision ledger, journal, candle history, and every other "learned state" subsystem MUST key its storage path by asset class (or specific ticker), not by mode alone. Mixing crypto learnings with stock learnings is a silent data-corruption bug that wipes out months of pattern accumulation.
type: feedback
originSessionId: 178e5620-a10e-4916-93d4-a046460eeb3c
---
**Rule:** Every subsystem that persists learned state (patterns, win-rates, decision logs, candle history, journal stats, pipeline snapshots) MUST write to an asset-aware path. Never share a file between asset classes.

**How this broke on 2026-04-22:**
`core/UnifiedPatternMemory.js:147-151` picks its storage path based on MODE only (`backtest`/`paper`/`live`) — no ticker in the filename. When the bot was on Kraken paper trading BTC/USD, it saved to `data/unified-patterns.paper.json`. When the bot flipped to Alpaca paper trading TSLA, it wrote to the SAME file. Over ~20 hours, TSLA pattern outcomes updated win-rates on signatures that were originally built from BTC behavior. 69,052 crypto patterns corrupted. No backup existed because the file was gitignored with no backup strategy.

Trey had flagged this need ("we need separate banks") in a prior conversation. It was NEVER implemented. Trey paid the cost on 2026-04-22 when the bot got flipped to stocks and the crypto pattern bank got poisoned before anyone noticed.

**Trey's exact words on 2026-04-22:** "we already had this conversation about needing separate banks and it didnt get done shocker and i suffer for it bigger shocker"

**How to apply going forward:**
- When reviewing any subsystem that keys off `BACKTEST_MODE` / `PAPER_TRADING` / mode alone for path selection, treat it as a bug. Fix it to include asset in the path: `unified-patterns.${mode}.${asset}.json`.
- Before flipping the bot from one asset class to another (e.g., crypto→stocks, or stocks→different ticker), AUDIT every subsystem that writes learned state. Specifically search for:
  - `storagePath`, `saveToDisk`, `persistPath`, `logFilePath`, `ledgerPath`
  - `process.env.BACKTEST_MODE`, `PAPER_TRADING`, `EXECUTION_MODE` used in path construction
- Every subsystem that doesn't include asset in its path is a landmine.
- Backups are mandatory for gitignored learned-state files. Gitignore protects against committing secrets, not against data loss.

**Systems that need asset-aware paths (audit scope):**
- `core/UnifiedPatternMemory.js` (patterns) — the one that got corrupted
- Decision ledger (`logs/decisions/decisions_{date}.jsonl`) — currently keyed by date only, mixes crypto and stock trades in the same daily file
- `core/TradeJournal.js` + `data/journal/journal-stats.json` — unknown
- `data/pipeline-snapshots.jsonl` — unknown
- `data/candle-history.json` — should be per-asset
- Any backtest-report files that aggregate across sessions

**Never delete this memory.** This is a permanent operational rule, not a point-in-time note.
