---
name: Mercury attack scope — hot-path code only
description: Mercury adversarial attack is reserved for hot-path/bot code changes (core/, brokers/, modules/, run-empire-v2.js, dashboard runtime). Not for config files, hookify rule files, docs, gitignored artifacts, or non-executable surfaces.
type: feedback
originSessionId: ecabee64-82e0-4ef6-b0a0-2c0a91dbddb8
---
**Rule:** Mercury adversarial attack passes are for hot-path / production-code changes — code that runs in the bot's execution path. NOT for config, rule files, markdown, schemas, gitignored data, or non-executable surfaces.

**Why:** Trey 2026-04-29: "no thats okay the mercury stuff is for really changes in the hot path and with the bot" — said in response to me offering to fire Mercury at the 27 hookify rule files before pushing. Mercury's value is finding edge cases, race conditions, state-mutation bugs, crash inputs in executable code. There's no equivalent surface in YAML config or markdown documentation — the worst-case "attack" is "does this YAML parse" which a config_loader test answers definitively.

**How to apply:**
- Mercury attack BEFORE push for changes to: `core/`, `brokers/`, `modules/`, `run-empire-v2.js`, `dashboard/` runtime code, anything in the trade execution path
- SKIP Mercury for changes to: `.claude/hookify.*.local.md`, `CHANGELOG.md`, `README.md`, `ogz-meta/specs/*.md` (canonical docs but not executable), config JSON without functional logic, gitignore, package.json metadata-only changes, comment-only edits
- Edge cases that DO need Mercury: schemas that drive runtime validation (manifest-schema.js, etc.), config that parameterizes hot-path behavior (TradingConfig, ExecutionConfig), shell scripts in the start/stop pipeline (`start-ogzprime.sh`, etc.)
- When unsure: ask Trey. The default for code-shaped files is "yes Mercury"; the default for config/docs is "no Mercury, just verify parse/syntax."

**Pattern:** This is about not wasting Mercury cycles on surfaces where it has no bugs to find. Mercury is finite — every config-file dispatch is a hot-path dispatch I didn't run.
