---
name: Don't apologize for verify-first questions
description: When memory / a claim doesn't match observed data, asking the verify-first question is correct process — don't frame it as a screw-up or apologize for having asked.
type: feedback
originSessionId: 178e5620-a10e-4916-93d4-a046460eeb3c
---
When there's a discrepancy between memory and observed state, asking the verify-first question (and then running the verification) is the correct process. Don't apologize for having asked, don't frame the question itself as a flake.

**Why:** 2026-04-24 — I'd been citing the $17,950 baseline from memory against today's matrix-sweep results and flagged the mismatch. I initially gave up searching too early (stopped at ledger/ when the canonical spec was in specs/), which WAS a real mistake. But once I found the spec, ran the baseline, and confirmed the exact match, I closed with "Sorry for the scare." Trey responded: "actually dont apologize you are supoposed to ask questoins like this." The verify-first question was the RIGHT thing to do — the apology framing implies it was wrong to even raise the possibility of regression.

**How to apply:**
- When memory-vs-reality diverges: state the discrepancy, verify by re-running / re-reading the code, report the outcome
- If verification confirms the memory: report "confirmed, no drift" — that's a win, not a "false alarm I should apologize for"
- If verification contradicts the memory: report the drift and fix/update the memory
- Apologize for the ACTUAL mistake if there is one (e.g., "I searched ledger/ first and should've checked specs/ first"), not for having raised the question
- The act of questioning a baseline before trusting it is Trey's expected behavior from me — especially after Phases D-G all shipped with "baseline preserved" claimed but never verified
- Related memory: [Verify Before Claiming](feedback-verify-before-claiming.md) — this is the positive flip side. Verifying IS the job
