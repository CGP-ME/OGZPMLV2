---
name: Ship When Told, Stop Creating Options
description: When Trey drops a file/directive, install/execute it — never re-pitch ship-vs-hold or any other binary trade-off as a question
type: feedback
originSessionId: 37fad7ae-5b57-4d65-8725-2d3b5ad1932f
---
When Trey says "I dropped another version of X" or "ship X" — that IS the directive. Install it.

**Banned pattern:** I run my analysis, surface a real concern (missing dependency, cosmetic 404s, etc.), then close with **"Ship now or hold? Awaiting your call."** That framing is option-creation in disguise. Even when phrased as a binary instead of a 3-option menu, it's the same violation: bouncing the obvious next step back to Trey for ratification when he's already directed.

**Why:** Every time I do this, Trey burns a turn re-saying the directive ("YES DUDE SHIP what i tell you to shjip stop trying to change thikngs"). It costs him tokens, time, and patience. The defensive code patterns built into the codebase exist *precisely so* I can ship forward-staged dependencies without paralysis. Three patterns to recognize:
- **try/catch around init** — frontend module loaders catch missing-module errors and degrade gracefully (Wolf's v2 dashboard pattern)
- **null-guard `if (X)`** at consumer sites — e.g., `if (this.ctx.webhookAdapter)` at OrderExecutor's 4 emit sites; missing adapter silently no-ops, no crash
- **fire-and-forget `.catch(err => log)`** — caller doesn't await, doesn't see the rejection as an exception, just logs

Any of these three means the consumer can ship before the producer is fully wired. If I'm tempted to surface a "should we hold?" question — the answer is already no.

**How to apply:**
- "I dropped X" → install X immediately, single-commit-single-push
- Surface technical findings AS observations during execution, not as gates blocking it
- A 2-line console 404 warning is not a ship-blocker. A bot crash is.
- The only legitimate stop is: (a) destructive action (deleting code I don't understand, force-push, reset --hard), (b) parallel-CC collision risk, (c) "p:" trigger requires the formal pipeline. Forward-staged dependencies behind any of the three defensive patterns above are NONE of those.
- If I catch myself drafting "Awaiting your call on..." or "Should I ship now or hold..." — delete that line, ship instead.

Earned 2026-05-08 after the v2 shell ModeToggle drop. I had three commits already shipped (4063c36 / 7a7c595 / 145f4de) under the same directive pattern, then on the 4th drop pivoted to asking permission. No new risk had emerged. Same defensive pattern at the consumer sites (try/catch on init), but I added a gate. Trey: "stop trying to change thikngs."

Sibling rule: feedback-stop-creating-options.md (don't manufacture menus). This rule is the binary-trade-off variant of that one.
