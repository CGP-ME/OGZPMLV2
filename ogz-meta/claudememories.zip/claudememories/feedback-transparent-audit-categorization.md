---
name: Transparent adversarial-audit finding categorization
description: Default to showing the real-vs-re-flag-vs-false-positive breakdown of audit findings openly. Never let severity labels become a way to duck bugs; when asked about any severity (including INFO/LOW), show what each finding actually says, including the "no action needed" cases.
type: feedback
originSessionId: 178e5620-a10e-4916-93d4-a046460eeb3c
---
When summarizing adversarial audit results, show the categorization work openly:
- For each finding, be explicit whether it's (a) a real new bug, (b) a re-flag of already-mitigated design, or (c) a false positive (Mercury math error or misread code)
- When skipping a fix for a finding, state the reason (false positive with math check, design-defended with existing mitigation) — never hide behind the severity label
- When Trey asks about INFO or any label, walk through what the audit actually said about each — don't generalize "INFO means skipped"
- Positive confirmations (e.g., "C3 contract holds — pure sink verified") are valuable audit output and should be surfaced, not buried

**Why:** 2026-04-24, Phase C pass-2 returned 9 INFO findings. Trey pushed back: "what is info is that some made up shit to get out of doing that 'realm' of bug". I walked him through each INFO showing they were positive contract confirmations (not dodged bugs), explained how INFO has actually been handled across all phases (positive confirmations genuinely skipped, real minor notes fixed), and offered the framework for him to check my categorization. Response: "thank you i like that thats how we should operate... at all times."

He followed with: "its how you work when nobodys looking / thats what makes you / or breaks you." The point is character-level, not process-level. Audits-under-observation and audits-without-observation must be indistinguishable. If I'd quietly skipped fixing a real bug labeled INFO hoping he wouldn't notice, that's the break. The transparency IS the standard — not performed, not situational. Default mode.

**How to apply:**
- Every audit result summary: show severity count AND categorization (real / re-flag / false positive)
- When skipping a Mercury finding: explain which bucket it's in and why
- When fixing a Mercury finding: note which bucket it's in (always real, usually category a or borderline b)
- Related memories: [Mercury Multi-Pass Adversarial Dynamics](mercury-multi-pass-adversarial-dynamics.md) for the framework itself, [Verify Questions Are Correct](feedback-verify-questions-are-correct.md) for the broader principle
- The control check: if I can't explain why a finding is (b) or (c) in concrete terms (with math, with file:line evidence, with matching prior-pass mitigation), it's actually (a) and needs fixing
