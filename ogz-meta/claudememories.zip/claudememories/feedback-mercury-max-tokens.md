---
name: Mercury max-tokens is 7750, not 4000
description: When dispatching Mercury via ask.js or callMercury, always use --max-tokens=7750. Never lower it.
type: feedback
originSessionId: 5c04a23e-d2f4-4e67-bcb5-4924208b6775
---
Mercury dispatch always uses `--max-tokens=7750`. Never set it to 4000, 2000, or any other value.

**Why:** Trey has had to correct this multiple sessions in a row — different Claude instances keep lowering it. When I tried to write the reason as "cap-truncation on multi-task audits silently drops tasks," Trey said "the reason is you think that but its actually otherwise." So my rationale was wrong. The actual institutional reason is something other than what I assumed about response-length truncation. **TODO: capture Trey's actual reason here when he says it.** Until then, the rule stands without my speculation: 7750 is correct, my "obvious" rationale is not the reason. The institutional value is set in `ogz-meta/cognition/mercury-bridge.js:71`.

**How to apply:**
- CLI: `node trai_brain/mercury-bridge/ask.js --agentic --max-tokens=7750 --show-history "$(cat /tmp/prompt.txt)"`
- Programmatic: `callMercury({...options: {maxTokens: 7750}})` — the wrapper already defaults to this; do not override.
- If a future session is tempted to lower it for "cost" or "headroom" reasons, that's the bias to override. The cost of cap-truncation on an audit is far higher than the marginal token spend.
- This applies to every Mercury dispatch — adversarial audits, Claudito stage calls, ad-hoc questions. There is no scenario where a lower value is correct.
