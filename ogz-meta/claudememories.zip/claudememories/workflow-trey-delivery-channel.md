---
name: Trey's delivery channel — notebook → WinSCP → ledger intake
description: When Trey runs an off-VPS tool (DeepSearch, Desktop Opus, ChatGPT, GPT-5, Gemini), the response is delivered via notebook → WinSCP → ogz-meta/ledger/. He never runs git for these. I curate.
type: user
originSessionId: a19c960d-8a89-41b1-8c1f-9d8a49816075
---
When Trey dispatches an off-VPS cognition tool (DeepSearch monthly budget, Claude Desktop Opus, ChatGPT, Gemini, etc.) and gets back a response that needs to land in the repo, his actual delivery workflow is:

1. Copy the response into his notebook (note-taking tool, off-VPS)
2. WinSCP (SFTP) into the VPS, drop the file into `ogz-meta/ledger/` — this is the "intake folder"
3. Tell me (Claude Code) it's landed, OR I read it from there

What I do (the curator role):
- Read the file from `ogz-meta/ledger/`
- Split / restructure as needed
- Move curated artifacts to indexed paths like `ogz-meta/specs/...` (Mercury indexes specs/, NOT ledger/)
- `git add` + commit
- Reindex Mercury via `node trai_brain/mercury-bridge/indexer.js`

**Why this matters:** I do NOT instruct Trey to run git commands. He's the delivery channel, I'm the curator. Telling him `git add X && git commit` is a layering violation — he doesn't operate git for intake; he operates WinSCP for intake.

**Corollary for outbound prompts:** When I write a prompt for DeepSearch/Desktop/etc. that mentions "save artifacts to path X," that's not an instruction the external tool can follow (it can't write files). It's structural guidance about where the artifacts will EVENTUALLY live after I curate them. I should NOT phrase it as if the external tool is responsible for the write, and I should NOT phrase an "activation step" as if Trey runs it.

**How to apply:**
- When Trey says "I'll notebook it and winscp it" — wait for the file to land, then I curate.
- Never phrase post-response actions as "you run X" when X is a git/indexer/curation step. Those are mine.
- Outbound prompts should specify eventual artifact homes for clarity, not for direct compliance.
- When the file lands, the activation sequence is mine alone: read ledger → split → move to specs/ → commit → reindex.

**Adopted:** 2026-05-11 after I closed a long DeepSearch prompt-building thread with "Activation reminder: git add && commit && reindex" and Trey called it out: "im confused what is this activation thing... im literalyl gunna notebook it and winscp it into the intake folder ledger."
