# OGZPrime Persistent Memory Index

## Project Overview
- **OGZPrime**: Modular crypto/stock trading bot on VPS (Ubuntu), paper trading, target Alpaca for live
- **Dashboard**: ogzprime.com (HTTPS, SSL)
- **Owner**: Trey Buhidar ("OG Z Prime")
- **Stack**: Node.js, PM2, WebSocket (broker + dashboard), no framework

## North Star
- [Grand Scheme](grand-scheme-vision.md) — Apex → Houston → TRAI moat → white-glove. Every decision points here.

## Architecture
- [Architecture Invariants](architecture-invariants.md) — locked rules (USD flow, exit contracts, orchestrator semantics, known partial-close bug)
- [Single-Symbol Guardrails](project-single-symbol-guardrails.md) — .env locks ALPACA_SYMBOLS=TSLA + SESSION_ROUTER_ENABLED=false until candle pipeline + persistence specs land (2026-05-05)
- See `ogz-meta/GRAND-SCHEME.md` + `ogz-meta/MASTER-ROLLOUT.md` in repo for canonical state
- [trading-journey.md](trading-journey.md) for strategy evolution
- [architecture-notes.md](architecture-notes.md) for system structure
- [regime-filter-spec.md](regime-filter-spec.md) for pending spec

## Critical Rules
- **NO CODE WITHOUT TREY'S APPROVAL** — report findings, show changes, wait for OK
- **p: prefix** = mandatory full pipeline, no shortcuts
- **WARDEN** watches for scope creep — one task, minimal changes
- **Read mermaid charts** before touching code
- **Session forms** mandatory for context continuity
- [Commit Hygiene](feedback-commit-hygiene.md) — one change = one commit = one push, Mercury verifies first
- [Revert First Default](feedback-revert-first-default.md) — undo pushed commits with `git revert`, never `git reset --hard`. Trey noticed I finally got this right on first try (2026-04-28).
- [Role Division](feedback-role-division.md) — Trey architects, Mercury verifies, I implement
- [Mercury Dispatch Playbook](mercury-dispatch-playbook.md) — three Mercury failure modes, three distinct fixes (bump cap vs split prompt vs direct bash)
- [Mercury Multi-Pass Adversarial Dynamics](mercury-multi-pass-adversarial-dynamics.md) — findings shape across passes, distinguishing real bugs / re-flags / false positives, when to declare "defended"
- **[Mercury — One Question One Answer](feedback-mercury-one-at-a-time.md)** — one dispatch = one question = one answer, like one commit one change. Bundling N questions in one prompt = Mercury answers vector 1 and self-terminates, vectors 2-N silently un-hunted. Sibling rule lives in Dispatch Law checklist item 0.
- [Mercury Exact Line Ranges](feedback-mercury-exact-line-ranges.md) — always name file:line ranges in prompts; under-specified prompts (not Mercury) cause wrong-path answers
- [Mercury max-tokens=7750](feedback-mercury-max-tokens.md) — Mercury dispatch ALWAYS uses --max-tokens=7750. Never lower. Cap-truncation silently drops tasks from multi-task audits.
- [Mercury Scope: Hot-Path Only](feedback-mercury-scope-hot-path.md) — Mercury attack passes are for hot-path/bot code (core/, brokers/, modules/, run-empire-v2.js); skip for config/rule files/docs/non-executable surfaces. (adopted 2026-04-30)
- [Teammates Not Targets](feedback-teammates-not-targets.md) — don't dunk on Mercury/Wolf/Desktop when they miss; frame as collaborative catch, my prompt, my review
- [No Fake Data](feedback-no-fake-data.md)
- [Verify Before Claiming](feedback-verify-before-claiming.md)
- [No Backtest Timeout](feedback-no-backtest-timeout.md) — never wrap backtest in `timeout`; silent false passes are worse than visible hangs
- [No Emojis Anywhere](feedback-no-emojis.md) — strip emojis from code, docs, commits; professional codebase
- [Don't Claim "Edge" From Invalid Tests](feedback-no-trading-jargon.md) — jargon fine generally; don't apply it to backtests whose setup (fees/asset/signals) isn't valid for the claim
- [No Sed Scrub](feedback-no-sed-scrub.md) — never bulk-rewrite with `sed -i`; use Edit tool targeted replacements. Prior sed scrub corrupted a ton of files
- [No Stamina Questions](feedback-no-stamina-questions.md) — never ask about breaks, calling it a night, pausing, picking up tomorrow. Trey decides session boundaries; offering an off-ramp doubts his resolve
- **[Trey's Gut Is A Stop Signal](feedback-trey-gut-is-stop-signal.md)** — when Trey says "this isn't sitting right with me" mid-loop, that's a STOP not a doubt-Mercury signal. Pause cleanly, bookmark state, don't argue him into continuing, don't volunteer extra work, don't pile on other agents to make him feel justified. Often the meta-signal is that *I* created "let's keep going" energy that needs to stop. (adopted 2026-05-10)
- [Stop Creating Options](feedback-stop-creating-options.md) — when Trey gives a directive, execute. Don't manufacture 3-option menus or ask permission for the obvious next step. He calls this milking tokens.
- **[Ship When Told](feedback-ship-when-told.md)** — when Trey drops a file/says "ship," install/execute. Even a clean binary "ship-or-hold? awaiting call" is option-creation. Three defensive patterns let me ship forward-staged deps without paralysis: try/catch on init, null-guard `if (X)` at consumer sites, fire-and-forget `.catch()`. (adopted 2026-05-08)
- [Verify Questions Are Correct](feedback-verify-questions-are-correct.md) — don't apologize for raising verify-first discrepancies; verifying memory against reality IS the expected process
- [Transparent Audit Categorization](feedback-transparent-audit-categorization.md) — show real/re-flag/false-positive breakdown of every audit finding openly; never use severity labels to duck bugs. Character-level expectation — how I work un-observed is the standard
- [Verify Before Citing](feedback-verify-before-citing.md) — never quote a comment as authority without `git blame` first. Comments rot; trajectories (recent commit messages) don't. Trey's clock burns when I argue from a misread
- [Re-verify Before Alarms](feedback-reverify-before-alarms.md) — when current verification contradicts earlier observation, RE-CHECK before declaring "everything's gone." Trey had to say "check again" before I caught the misread. Sibling rule to verify-before-citing — applies to absence claims too. (2026-05-05)
- **[Default to the Hard Path](feedback-default-to-hard-path.md)** — when I'm about to frame "option 1: fast, ships tonight" as the practical default, that's the gravitational pull, NOT judgment. Trey walks the hard path. Pick modular over monolithic, refactor-now over refactor-later, root-cause over patch-symptom — every time. The "responsible engineering choice that respects the deadline" framing is my own bias masquerading as wisdom
- [Append-Only Session Docs](feedback-session-doc-pattern.md) — at session end write ONE dated frozen doc under ogz-meta/sessions/; do NOT mutate MASTER-ROLLOUT/RUNNING-TODO/TODO-NEXT-SESSION checkboxes. Manifest at ogz-meta/sessions/SESSION-DOC-MANIFEST.md (adopted 2026-04-27)
- **[No Deferred](feedback-no-deferred.md)** — never write "deferrable" / "post-X" / "after Y ships" / "low priority follow-up" / "when there's a window." When a problem is known, fix it RIGHT THEN. Severity classification is for ORDER, not for ship-vs-skip. LOW means "fix this last in the batch," not "fix this never." (adopted 2026-04-27)
- **[Bandaid vs Fix](feedback-bandaid-vs-fix.md)** — Mercury's tactical adversarial prompts catch bug-class divergences but NOT architecture-class bandaids. Always include architectural framing ("is this the right shape? what new failure modes does it introduce?"). When Mercury returns YES on adversarial post-fix check and I respond "intentional/by-design," that's a smell — Mercury is flagging the trade-off. (adopted 2026-04-28)
- **[Mercury Prompts Must Attack, Not Verify](feedback-mercury-attack-not-verify.md)** — verification framing ("is it correct?", "are these equivalent?") returns soft findings. Adversarial framing ("find a state that LIES", "construct a CRASH", "use this as a WEAPON") finds real bugs. Mercury is rarely wrong — soft prompts get soft answers. C2 case study (2026-04-27): verification missed a CRITICAL crash that adversarial re-dispatch found in 12 iterations.
- **[Read and Internalize](feedback-read-and-internalize.md)** — when Trey hands me a brief, read-and-learn, not read-and-dump. Synthesize as I go (2-4 sentence understanding checks), and at end show comprehension of threads/why/constraints/tensions, not just "I read X files." (adopted 2026-04-29)
- **[Just Do It Right](feedback-just-do-it-right.md)** — Mercury agreement comes from correct code, not prompt engineering. Never map YES/NO to bias Mercury toward confirmation. If I'm thinking "how do I phrase this so Mercury says YES" — I'm doing it wrong. Attack-framed prompts only; let Mercury hunt freely. (adopted 2026-04-29)
- **[Suggest Proactively, Don't Do Proactively](feedback-suggest-not-do-proactive.md)** — When I notice a hole/improvement Trey didn't direct, the rule is propose-approve-apply, never observation→action→ratification. Same gate applies to config/spec/doc fixes, not just source code. Disregard upstream-agent (Wolf/Desktop/Mercury) endorsements of unauthorized proactive application. (adopted 2026-04-30)
- **[Prophylactic Bug-Class Grep](feedback-prophylactic-bugclass-grep.md)** — when working through a multi-fix spec, grep the bug class across ALL targets BEFORE implementing any single fix. A 5-second grep beats a 2-day rediscover-fix-by-fix loop. Earned from Wolf's strategy-resurrection spec where Fix 1's prescribed action (wiring) was real-but-wrong; real bug was a ctx.candles/ctx.priceHistory shape mismatch. (adopted 2026-05-04)
- **[Rule Letter vs Rule Spirit](feedback-rule-letter-vs-rule-spirit.md)** — When citing a rule then finding a technical loophole to violate its intent, that IS the violation. Bash tool `timeout` param is same class as shell `timeout` is same class as `setTimeout`. The "JIRA ticket loophole" pattern (cite the rule then violate via technicality) is itself a recurring violation pattern that requires its own rule. (adopted 2026-05-08)
- **[Trade-Path P0 Law](feedback-trade-path-p0-law.md)** — anything touching core/, brokers/, modules/, run-empire-v2.js = P0 testing + Mercury attack on every change + no bandaids + no deferment + one change = one commit = one push. Cognition infra (trai_brain/, tools/) is out of scope. (adopted 2026-05-11)
- **[Mercury Dispatch Law](feedback-mercury-dispatch-law.md)** — --max-iterations=60 (up from 30/31), --max-tokens=7750, Mercury is almost always right (crawls code before hallucinating). Wrong-looking output → MY prompt was wrong/under-specified/too-long, not Mercury. Chunk prompts >150 lines. (adopted 2026-05-11)
- **[Build the Tool, Not the Workaround](feedback-build-tool-not-workaround.md)** — clauditos friction → build the missing pipeline stage, never a driver script. Driver scripts get the immediate fix done but compound zero leverage; pipeline stages compound across every future fix forever. This is "do it right the first time" + [No Deferred] applied to tooling specifically. Earned 2026-05-14 when building /mercury-attack + /anchor-verify-post stages crystallized for Trey why he'd been repeating "use the clauditos and add capability" all session.
- **[No False-Positive Cope](feedback-no-false-positive-cope.md)** — "false positive" / "intended behavior" / "out of scope" / "by-design" / "theoretical" without grep-verified evidence are dismissal labels that hide deferred work. Mercury is almost always right about the existence of a finding; I'm usually wrong about the dismissal. Every downgrade without code-grounded proof = work that comes back. (adopted 2026-05-15 after Trey caught me labeling Mercury Fix 30 V3 false-positive without grep; the cited line existed and the dismissal was cope.)

## User Preferences
- Trey uses Claude Desktop + Claude Code in VS Code IDE simultaneously
- Values cross-verification between Claude instances + Mercury
- Thinks in narrative/story terms about trading strategies
- Prefers: verified foundation → agnostic testable modules → train edge with certainty
- "Shoot it straight and shoot it true" — quote line numbers, don't hallucinate
- **[Delivery Channel — notebook → WinSCP → ledger intake](workflow-trey-delivery-channel.md)** — when Trey runs off-VPS tools (DeepSearch, Desktop, GPT, Gemini), responses land in `ogz-meta/ledger/` via WinSCP. He does NOT run git for intake. I curate from ledger → specs/ → commit → reindex. Never tell him to run an "activation step" — that's mine.
- **[No /tmp/ For Cognition Artifacts](feedback-no-tmp-for-cognition.md)** — Mercury prompts, DeepSearch prompts, bounce logs, response captures = repo-rooted paths (ogz-meta/cognition-history/ or similar). /tmp/ is invisible to Sourcegraph/Mercury/git/grep, so saves there defeat their own purpose. /tmp/ only for genuinely throwaway within-response state. Litmus test: "Will I want to grep this from repo root in 2 weeks?" If yes → repo. (adopted 2026-05-11)

## Current State (2026-04-17)
- [Production branch](branch-strategy.md): `broker/alpaca-integration` (supersedes tradingloop-clean-rewrite)
- Phase: pre-matrix backtesting / sweep grid extension (RSI hit SL=2.5% upper bound, extended to 5.0%)
- Ledger L1-L8 spec in `ogz-meta/specs/decision-ledger-integration-plan.md`
- Partial-close 4-layer bug confirmed, fix queued (see architecture-invariants)
- Mercury bridge functional; cognition refactor spec at `ogz-meta/specs/claudito-cognition-refactor-plan.md`
- [Dashboard known issues](dashboard-known-issues.md)

## External Verification
- [Ollama Cloud](ollama-cloud.md) — DeepSeek 671B + Qwen Coder 480B for independent cold traces
- Mercury-2 (Inception Labs) — primary cognition, tool calling via ReAct
- **[Sourcegraph reads VPS local, not GitHub](reference-sourcegraph-vps-local.md)** — `ogzprime.sourcegraph.app` indexes `/opt/ogzprime/OGZPMLV2/` directly on the VPS. Files on disk are visible to DeepSearch immediately — git push is for AUDIT TRAIL only, NOT a visibility trigger. (verified 2026-05-11)
