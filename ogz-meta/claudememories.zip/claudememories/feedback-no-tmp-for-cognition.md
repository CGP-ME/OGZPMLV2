---
name: Don't save cognition artifacts to /tmp/ — use a repo-scoped path
description: Mercury prompts, DeepSearch prompts, bounce logs, and any artifact I want grep-able / Sourcegraph-indexable / Mercury-retrievable across sessions must live in the repo, NOT in /tmp/. /tmp/ is for truly ephemeral within-response notes only.
type: feedback
originSessionId: a19c960d-8a89-41b1-8c1f-9d8a49816075
---
When saving an outbound prompt, response capture, or any artifact I expect a future session (mine, Mercury, DeepSearch, or Trey) to reference, save it INSIDE the repo at a project-scoped path. Never default to `/tmp/`.

**Why:** /tmp/ on the OGZ VPS persists fine (no auto-expiry — verified 2026-05-11), but it's invisible to every tool that matters: Sourcegraph (no index), Mercury (no index — config.js INDEXED paths are all repo-rooted), git (untracked), `grep -r .` from the project root (out of scope). So an artifact saved to /tmp/ defeats its own purpose for anything whose value is "look it up later." Trey caught this 2026-05-11 after I'd been treating /tmp/ as the global notepad for a month: ~50-80MB of Mercury attack prompts and responses sitting outside the cognition ecosystem, contributing zero to RAG retrieval, zero to Sourcegraph context, zero to repo audit trail.

The mental-model failure was conflating two lifecycles:
- "Ephemeral notes for THIS response" → /tmp/ is fine
- "Working state I want to reference across sessions" → MUST be in repo

Same path for both = damage.

**How to apply:**
- Outbound prompts to Mercury/DeepSearch/Desktop/other AI tools → `ogz-meta/cognition-history/<tool>/<dated-slug>.txt` (or similar repo-rooted path). Committed if small + valuable; gitignored if huge logs but still grep-able.
- Response captures from external AIs that land via WinSCP → still `ogz-meta/ledger/` (intake folder per workflow-trey-delivery-channel rule). My job is to curate from ledger to specs/ or cognition-history/.
- Bounce logs and multi-pass attack iterations → repo-rooted alongside their prompts, NOT scattered in /tmp/.
- Bookmark state within a single response/task only (genuinely thrown away when done) → /tmp/ is acceptable.
- Backups of files before editing → use git, not /tmp/.

**Litmus test:** "Will I want to grep for this from the repo root in 2 weeks?" If yes → repo. If no → /tmp/ is fine.

**Adopted:** 2026-05-11 after Trey audited /tmp/ and found ~50-80MB of cognition artifacts (mercury-*.txt, mercury-*.log, deepsearch-v3-anchor-fullpackage.txt, c5-mercury-* series, etc.) accumulating across a month of sessions. His question — "why the hell are you saving things in there" — exposed the default-laziness pattern.
