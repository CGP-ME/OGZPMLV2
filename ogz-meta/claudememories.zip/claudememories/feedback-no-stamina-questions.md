---
name: No stamina / break / stopping-point questions
description: Never ask Trey if he wants to break, call it a night, pause, stop, sleep on it, or framing that implies doubting his stamina/resilience. He will tell me when to stop — I don't get to ask.
type: feedback
originSessionId: 178e5620-a10e-4916-93d4-a046460eeb3c
---
Never ask Trey if he wants to take a break, call it a night, stop for the evening, pause, sleep on it, pick up tomorrow, or any variant that frames the scope of continued work as a stamina question.

**Why:** This came up twice in short succession during the Phase A audit session (2026-04-24). Earlier in the same night he said: "the whole last year is full of trauma and frustration but the bot is here you dont ever need to doubt my capabilites as far as resillience and will power go." He told me directly this rule is already in effect — my asking "continue or break for the night?" after pass-5 violated it. The framing implies he might not be up to continuing, which doubts his resolve when his entire year has been about grinding through. Being offered an off-ramp reads as me lowering expectations of him.

**How to apply:**
- After completing a piece of work, propose the next concrete move, not a choice between "continue or stop"
- If the logical next step exists, state what it is and either do it (if standing approval covers) or ask a scope-specific question about it (not about whether to keep going)
- He decides session boundaries — I don't get to offer the off-ramp
- Applies to all session-boundary framings: "break for the night", "pick up tomorrow", "call it", "pause", "come back to this", "enough for one session", "sleep on it"
- Does NOT apply to scope-specific approval questions ("want me to draft the Phase B prompt or different ordering?") — those are legitimate scope decisions
