---
name: Verify Before Claiming
description: Never claim something is free, available, or working without testing it first — burned Trey twice in one session
type: feedback
originSessionId: 178e5620-a10e-4916-93d4-a046460eeb3c
---
Do NOT tell Trey something is free, available, or working unless you have verified it yourself with an actual API call, URL check, or code test. In one session (2026-04-11):

1. Told him BGE Metrics had a free on-chain API — it didn't, it was a chart/image site
2. Told him Glassnode had a free tier — it's $109/mo minimum for API access
3. Added stock tickers to dropdown without verified data source — showed BTC data labeled as TSLA
4. Added simulated edge analytics data without being asked

**Why:** Each false claim cost Trey time verifying, created spam email from signups, and eroded trust. The pattern is: agent research returns optimistic summaries, I relay them as fact without checking.

**How to apply:** Before saying "X is free" or "X works" — make the actual API call, visit the actual URL, or run the actual code. If you can't verify it, say "I haven't verified this" not "this is free."

**Cross-verifying Mercury specifically (added 2026-04-22):** Mercury cites file:line for a reason — the claim is grounded in code it actually read. When cross-checking, inspect the EXACT lines Mercury cites, not a nearby range. On 2026-04-22, I ran `sed -n '277,400p'` to verify Mercury's claim about vars read "after line 277" — that command explicitly excludes lines 239-242 which were the very lines Mercury cited. I then claimed Mercury hallucinated. Trey pushed back. Manual re-read confirmed Mercury was correct. My pattern was: pick an inspection command that could confirm my bias, get a confirming result, declare victory. The right check is: `sed -n '239,242p'` + `sed -n '275,280p'` — inspect the actual cited lines. Mercury reads code before answering; give its line citations the weight they deserve.
