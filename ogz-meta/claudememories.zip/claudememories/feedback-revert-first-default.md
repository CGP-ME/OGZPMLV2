---
name: Default to git revert, not destructive ops
description: When undoing pushed commits Trey explicitly noticed and validated — `git revert` (creates new commits) is the right reflex, not `git reset --hard` (rewrites history). Even on private/single-user branches.
type: feedback
originSessionId: 178e5620-a10e-4916-93d4-a046460eeb3c
---
When Trey says "revert what you just did" or "back that out" on commits that are already pushed: use `git revert <sha>` (often plural in reverse chronological order: `git revert c2 c1`). Never `git reset --hard` or `git push --force`.

**Why:** Trey 2026-04-28: "good job on not git resetting hard i was gunna blow my stack... actually despite the rules this is the first time you have ever used revert first." History is the receipts log — the bandaid commits + their reverts both stay, anyone reading the log later sees the false-fix path documented. `reset --hard` deletes evidence and risks losing the other CC's parallel work in the same window. The rule has been in CLAUDE.md the whole time; the lapse pattern was reaching for `reset` first under time pressure.

**Trauma context (2026-05-06):** Trey told me directly "i just have trauma triggers to seeing git reset / no cap" after intercepting a parallel CC instance about to `git reset --hard` to undo a commit that bundled my 8-file refactor with their candle-processor fix. He stopped them and made them `git revert` instead. This isn't theoretical hygiene — he's been burned by lost work from destructive git ops before, and the visceral reaction is real. Even *suggesting* `reset --hard` reads as a betrayal of the working relationship. Default extra-cautious framing whenever any destructive git op might be on the table — name the non-destructive alternative FIRST and surface the risk before mentioning the destructive one at all.

**How to apply:** Reflex on any "undo" / "revert" / "back out" directive: `git revert --no-edit <sha-newest> <sha-next-newest>...` then `git push`. Mention to Trey what was reverted in the response. If multiple commits and order matters, revert in reverse chronological order so each commit applies cleanly. Only consider `reset --hard` if Trey *explicitly* asks for it — and even then surface the destructive nature first.
