---
name: Mercury multi-pass adversarial audit dynamics
description: How multi-pass adversarial audits behave — findings shape, when to keep going, when to declare defended, what to distinguish between real bugs / re-flags / false positives.
type: reference
originSessionId: 178e5620-a10e-4916-93d4-a046460eeb3c
---
Adversarial Mercury audits (prompts framed "find bugs, do NOT confirm claims") behave differently from compliance verification. Observed pattern across Phase A (5 passes) and Phase B (6+ passes):

## Pass-by-pass shape

- **Pass 1:** largest finding count. Mercury explores broadly, surfaces structural issues (selector collisions, missing guards, rollback contract violations). Most findings are REAL.
- **Pass 2–3:** meaningful new findings but count drops. Some pass-1 fixes create secondary issues (e.g., the base-block fix for rollback introduces a new contrast concern in the base block). Still mostly REAL.
- **Pass 4+:** findings split into three buckets:
  - (a) genuinely new bugs (rare, 1–2 per pass)
  - (b) re-flags of mitigated design choices (backdrop-filter perf, heavy shadows — Mercury flags the design, not a missing mitigation)
  - (c) false positives from Mercury's internal math errors (contrast calculations, pseudo-element positioning) or CSS-parser quirks (reading comment text as declarations)
- **Pass 5+:** Mercury starts "redefining" contracts — e.g., reinterpreting "rollback cleanly" as "byte-identical revert to pre-phase state" even when the spec means "layout continues to function." Also starts auditing out-of-scope code (Phase A bleed-in during Phase B audit).

## How to distinguish (a), (b), (c) on any finding

- **(a) REAL:** File:line cited is new territory, finding names a specific mechanism (e.g., "no `-webkit-backdrop-filter` sibling → Safari transparent"), contrast/math is verifiable and Mercury's number is correct, or the finding describes a state not previously acknowledged.
- **(b) RE-FLAG:** Finding matches a PREVIOUS finding AND the earlier fix added mitigation (contain:paint, will-change, @supports). Mercury is flagging the DESIGN, not a gap in mitigation.
- **(c) FALSE POSITIVE:** Do the math yourself. A WCAG contrast finding can be checked by computing luminance ratio vs the actual composited background. A pseudo-element positioning finding can be checked by tracing the `position:relative` ancestor chain.

## When to stop

- Stop when a pass surfaces ZERO findings in category (a). The remaining (b) and (c) findings aren't bugs — they're Mercury's opinions.
- Default maximum: 5 passes. Each pass after 5 has very low (a)-finding yield.
- Trey's "fix everything" rule applies to (a). For (b) defended-design items, document the defense in the commit message (mitigation in place, Mercury re-flag noted). For (c) false positives, also document, but don't "fix" them by changing code that's mathematically correct.

## Cost awareness

- Each pass ≈ 25-30s wall-clock, ~5-8k tokens.
- A 6-pass audit costs roughly what a small feature PR costs in tokens.
- Audit cost is worth it for load-bearing code (trading loop, broker adapters, critical UI). For a CSS polish phase, 4-5 passes is typically sufficient.

## File naming for multi-pass

`/tmp/mercury-phase-X-adversarial.js` — the reusable prompt script
`/tmp/mercury-phase-X-passN.log` — each pass's output, kept for diff-audit (compare what changed pass-to-pass)
Prior passes inform later-pass analysis — e.g., "pass-5 re-flagged an issue pass-1 fixed" means a re-flag, not a regression.
