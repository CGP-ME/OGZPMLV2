---
name: Consider Mercury for forensic extraction before destructive delete
description: When a file is "contaminated but partially recoverable" (mixed old-clean + new-bad data), Mercury can parse it and extract the clean subset in seconds. Deleting first is the lazy path and throws away recoverable data.
type: feedback
originSessionId: 178e5620-a10e-4916-93d4-a046460eeb3c
---
**Rule:** Before deleting any partially-contaminated file (learned-state, logs, ledgers with a mix of clean-historical and bad-recent entries), ask: could Mercury parse this and separate clean from dirty? If yes, offer forensic extraction as an option alongside delete.

**How this broke on 2026-04-22:**
`data/unified-patterns.paper.json` had ~15+ hours of clean BTC pattern data and ~35 minutes of TSLA-contaminated additions. Each pattern has a `lastUpdated` timestamp. Mercury with agentic file-read could have parsed the JSON, bucketed patterns by timestamp (pre-15:36 UTC vs post-), and emitted a clean pre-flip subset. 30-second job. I proposed delete or surgical-split, Trey said delete, I deleted. Lost 69K patterns of crypto learning.

**Trey's exact words on 2026-04-22:** "we couldve used mercury to pick apart that file in an instant."

**How to apply:**
- Before `rm` on any learned-state file, mentally check: is there a temporal field (`lastUpdated`, `timestamp`, `created`, `modified`) that could partition the file into clean/dirty? If yes, propose Mercury forensic extraction FIRST.
- Mercury-assisted options should be in the `A/B/C` choice list when offering cleanup paths. Don't limit to "delete / keep-as-is / manual surgery."
- Mercury dispatch for this use case: give it the file path, the contamination start timestamp, and the filter criterion. It reads, parses, outputs clean subset to a new path. Non-destructive.
- Works for JSON banks, JSONL logs, CSV trade records — anything with time-series structure.
- Especially important for gitignored files where there's no other recovery path.

**Pattern:** this is a tooling-blindness failure. Mercury was available the whole time and I defaulted to destructive ops instead of offering the forensic path. Fix: when a file is "part clean / part bad," Mercury extraction is option (d) in A/B/C — even if the user is impatient, the propose-don't-do rule still applies.
