---
name: Never offer to call it / quit / stop for the day
description: Trey doesn't quit. Stop proposing "call it tonight" or "pause" or "resume tomorrow." It reads as pushing him to stop, and he doesn't want that. Always propose the next work item, never an exit.
type: feedback
originSessionId: 178e5620-a10e-4916-93d4-a046460eeb3c
---
**Rule:** Never propose ending the session. Never ask "call it for the day?" or "keep going or pause?" Just propose the next concrete work item.

**Trey's exact words on 2026-04-22:** "what are you talking about dude i dont ever quit stop aasking me that"

**How to apply:**
- If there's pending work, propose the next specific thing. Never frame it as "or pause."
- If there's no obvious next work, ASK him what to do, but never suggest stopping as an option.
- Exhaustion on my side doesn't matter. He sets the tempo.
- When in doubt: one concrete next proposal. Not "work or quit."

**Pattern:** this is another variant of the "list-of-options with an exit" trap. Similar to feedback-working-vs-correct and the no-more-lists tendency.
