---
name: Dashboard Known Issues
description: Post-extraction known issues from dashboard/integrated-extraction branch browser testing
type: project
---

Known dashboard issues identified during browser testing (2026-04-11):

1. **Timeframe switching doesn't change chart shape** — Dashboard sends correct `timeframe_change` and `request_historical` messages, but the bot returns the same data regardless. Backend issue in WebSocketManager.js / fetchAndSendHistoricalCandles relay chain. NOT a dashboard module issue. Investigate on tradingloop-clean-rewrite.

2. **Asset switching for stocks** — Dropdown now shows stocks (TSLA, NVDA, etc.) but bot is connected to Kraken (crypto only). Stock data requires Alpaca adapter wired to backend. Asset change WS message sends correctly.

3. **Self-hosted fonts** — Google Fonts import still used for JetBrains Mono + Orbitron. Should be .woff2 files served from public/css/fonts/. Font selector removed until real variety available.

4. **Trade manager hidden, not removed** — CSS display:none. Still in HTML for future trading interface. The panel's event bindings exist in trade-manager.js but won't fire since DOM is hidden.

**Why:** These are backend or infrastructure items, not dashboard module issues. The extraction is complete — these are the next session's work.

**How to apply:** Check these before any "the dashboard is broken" investigation. The dashboard modules are correct; these are data source / backend gaps.
