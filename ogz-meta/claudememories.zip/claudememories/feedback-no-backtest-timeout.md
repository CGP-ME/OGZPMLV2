---
name: Never put a timeout or tail on a backtest
description: Timeouts AND output truncation (tail/head) on backtests destroy observability — there is no data to observe. Run full output to completion, no caps, or let it hang visibly.
type: feedback
originSessionId: 178e5620-a10e-4916-93d4-a046460eeb3c
---
**Rule:** Never wrap a backtest command in `timeout` (or any time-based kill wrapper), AND never pipe its output through `tail`, `head`, `grep`, or any other truncation. Run the backtest, let all bytes reach disk/screen, let it complete (or hang visibly).

**Why:** Trey's framing on 2026-05-04: *"there's no data to observe that way."* The deepest reason isn't just "silent false passes" — it's that truncated/timed-out runs eliminate the data entirely. You can't verify against bytes that never made it to you.

- A `timeout 300` firing mid-run kills the Node process without warning. If the harness doesn't explicitly check for a `BACKTEST COMPLETE` marker, a killed run looks identical to a successful one — no error, no exit code difference visible at a glance, just truncated output. Silent false-pass regression tests.
- A `| tail -50` hides everything except the trailing summary block. Worker exceptions, partial-batch failures, warnings, NaN propagation in batches 1-9 of a 12-batch sweep all scroll past unseen. The summary block at the end still prints because matrix-sweep doesn't fail loudly on partial completion. The result *looks* clean.

The very best thing that can happen when a backtest is misbehaving is that nothing happens (it hangs visibly, full output present) — that forces the diagnosis.

**How to apply:**
- Do NOT use `timeout 300 node run-empire-v2.js` or similar.
- Do NOT pipe backtest output through `tail`, `head`, or any line-truncating filter to keep stdout short. Full stdout, every byte.
- Do NOT use the Bash tool's `timeout` parameter as a backtest cap — same effect as `timeout`, same silent-kill risk.
- Do NOT use `run_in_background` with an artificial cap as a timeout substitute.
- If output is genuinely too long for terminal: redirect to a file (`> sweep.log 2>&1`), run in background, then read the file with the Read tool when the process exits. The data must exist somewhere readable in full.
- If a backtest hangs: kill it manually, diagnose the hang, fix it. Don't automate the killing.

Verified corrections: 2026-04-21 (timeout); 2026-05-04 (tail/timeout combo on matrix-sweep, after sweep happened to fit luckily — Trey's framing: "there's no data to observe that way").
