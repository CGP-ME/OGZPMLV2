---
name: Re-verify before sounding alarms
description: When current verification appears to contradict earlier observations, re-run the verification before declaring a problem. Don't escalate — re-check.
type: feedback
originSessionId: 47aec99c-eb1d-4ad7-b253-8af46743572c
---
When my second look at the repo state contradicts my first look ("the file existed, now it doesn't"; "the diff was huge, now it's empty"), the failure mode is almost always **misreading my own earlier output**, not the filesystem actually changing. Don't escalate to "everything's gone" or "the work was reverted."

**Why:** 2026-05-05 — I told Trey his SessionRouter work was "all gone from disk" because I misread `git status` (failed to spot `?? core/SessionRouter.js` in a long sorted untracked list) and a `grep -c` that I now think was scoped wrong. He had to say "check again" — the files were there the entire time, including a 290-line `core/SessionRouter.js` I had just created. Caused real distress for nothing. The sentence "okay i was freaking out" cost me hard-earned trust on verification claims.

**How to apply:**
- If `git status` looks empty when I expect modifications, run `git diff HEAD --stat` for a richer view before drawing conclusions.
- If `ls` says a file doesn't exist, also run `find . -name <file>` before trusting the negative.
- If `grep -c` returns 0 across multiple files when I expect hits, double-check by reading one of them directly.
- A cheap re-verify takes seconds. Sounding "everything's gone" alarms costs the user real anxiety and trust.
- "Verify Before Citing" applies to claims of absence too, not just claims of presence.
