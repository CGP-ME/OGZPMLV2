---
name: Mercury audit prompts — always name exact file:line ranges
description: After Mercury answered the wrong code path by grepping and stopping at first plausible match, the fix is to pin exact line ranges in the prompt so it opens the RIGHT block.
type: feedback
originSessionId: 178e5620-a10e-4916-93d4-a046460eeb3c
---
When dispatching Mercury agentic audits, **always name the exact file:line ranges Mercury must open** in the prompt. Mercury's ReAct loop defaults to `grep` → `open_file` on first plausible match → stop. If the question requires a specific block and multiple blocks match the grep terms, Mercury will land on the wrong one and confidently answer using the wrong code.

**Observed failure (2026-04-22):** Audit question was about PROFIT TIER path in MaxProfitManager.js (lines 494-516). Mercury grepped for `SELL`, `emit`, `intent`, `shouldExit`, `exitSize`, matched first at line 460-466 (the BE Scale-Out return block — same `action: 'exit_partial'` pattern but completely different code path). It returned verdict WIRED-CORRECTLY citing only the BE Scale-Out path, never opened the tier path at lines 498-515 or the tier setup at 650-715. Direct-read found a real math concern (tier4 fraction=1.0 vs `fraction<1` guard) that Mercury missed.

**Why:** Mercury does not cross-reference multiple matches when it finds something plausible. The ReAct loop terminates as soon as the model thinks it has enough evidence. If the prompt is open-ended ("find the tier exit path"), Mercury follows its own nose; if the nose is wrong at first sniff, the whole audit is wrong.

**How to apply:**
1. Before dispatching, grep the codebase yourself to identify the EXACT line ranges Mercury must verify.
2. In the prompt, list those ranges explicitly: `core/MaxProfitManager.js:494-516`, `core/StateManager.js:577-607`, etc.
3. If there's a similar-looking block that Mercury might confuse with the target, **tell it not to audit that block**. Example: "DO NOT audit BE Scale-Out at lines 460-466. Audit ONLY the profit-tier block at 494-516."
4. For multi-file traces, list every file:line Mercury needs in order. Don't let it choose the path.
5. Demand short structured output (CLAIM A/B/C with file:line, FINAL VERDICT) so you can quickly check if Mercury cited the intended code.

**Applies to:** All Mercury agentic audits verifying code paths. Tighter prompt = shorter iteration count = less chance of drift. This also dovetails with the Mercury Dispatch Playbook — a tightly scoped prompt rarely hits `max_iterations`; a sprawling one often does.
