---
name: Architecture Invariants that survive every refactor
description: Core invariants locked across audits — do not violate without Trey's explicit approval
type: project
originSessionId: 178e5620-a10e-4916-93d4-a046460eeb3c
---
**Position size flows in USD** throughout the pipeline (no asset-unit conversions mid-flight). Legacy BTC-named variables may still appear in stock code — the math is USD-based regardless.

**Exit contracts are locked per strategy** with `_validated` fingerprints in `core/TradingConfig.js` `BASE_CONFIG.exitContracts`. Env vars `STOP_LOSS_PERCENT`/`TAKE_PROFIT_PERCENT`/`TRAILING_STOP_PERCENT` are IGNORED by strategies with locked contracts (verified 2026-04-07, `ogz-meta/ENV-VAR-AUDIT.md`). Tuning = edit the locked block + walk-forward validate + new `_validated` date. NEVER tune via env-var sweep.

**Backtests use the same code path as live** — `EXECUTION_MODE=backtest` + `CANDLE_SOURCE=file` feeds `BacktestRunner` → `handleMarketData` → `TradingLoop.analyzeAndTrade`. No standalone backtest scripts allowed (the `tuning-backtest-full.js` parallel universe caused every bug we found on 2026-03-11).

**Account isolation** — every Apex clone runs as its own process, its own state file, its own log directory, its own kill switch. One account's bug never cascades.

**Orchestrator picks ONE winner per candle** — strategies are evaluated independently, highest-confidence winner executes, confluence multiplier (1.0 → 2.5x) applied AFTER winner selection based on how many strategies agreed on direction. Strategies do NOT blend. DEC-004 in MASTER-ROLLOUT.md.

**Position sizing stack** (OrderExecutor.js:55-81): base × confidence × confluence. Theoretical max 31.25% (5% × 2.5 × 2.5) never fires — observed max stays below 15%. DEC-012.

**Pattern memory is NOT namespaced by asset** — setup is a setup regardless of ticker. Only mode (live/paper/backtest) namespaces are allowed. DEC-002.

**Brain bug (4-layer partial-close) is FIXED** as of 2026-04-16. Verified in code 2026-04-17:
- `core/StateManager.js:574` `reducePosition(tradeId, fraction, price, ctx)` exists and rejects invalid fractions
- `core/StateManager.js:438-443` `closePosition` hard-rejects partial calls and redirects to `reducePosition`
- `core/OrderExecutor.js:611` uses `decision.exitFraction` (correct semantic); legacy `exitSize < 1` kept as fallback at `:614`
- `core/OrderExecutor.js:928, 935` — `removeActiveTrade` and MPM reset both gated on `!isPartialClose`

Commits that killed it: `50eff2a` (Set A, F1-F5), `cb04261` (F6-F9, F16, F19), `dcb8391` (Set C, F10-F13), `0b4acc5`/`91708ca`/`0ab1a86` (scope hoist follow-ups). The 19/19 confirmed findings in the Mission 0.5 brain-bug spec (commit `50deeab`) were fully executed. The forensic-trace specs at `ogz-meta/specs/partial-exit-forensic.mmd` and `ogz-meta/specs/trade-lifecycle-trace-table.md` describe the PRE-FIX state — they're historical, not current. Don't treat them as live code behavior.

**How to apply:** Before proposing changes that touch position sizing, exits, or backtest pipeline, reference the relevant spec first and verify the invariant still holds in current code. Don't trust memory alone — invariants have been proven wrong before (e.g., "multi-broker is vapor" was wrong per Mercury Part 2 audit 2026-04-13).

---

## Docs folder hierarchy (stated by Trey 2026-04-17)

Read in this priority order — do NOT skim or skip:

1. **`ogz-meta/` top-level** = MOST relevant. Current architecture, alignment docs, how-to-do-everything operational reference (GRAND-SCHEME, MASTER-ROLLOUT, BACKTEST-OPS, BACKTESTING_GUIDE, ENV-VAR-AUDIT, landmines, guardrails, methodology).
2. **`ogz-meta/specs/`** = canonical schemas + verified designs. Indexed by Mercury as authoritative.
3. **`ogz-meta/cognition/`** = Mercury bridge infrastructure (mercury-bridge.js, prompts.js, parsers.js).
4. **`ogz-meta/ledger/`** = NOT canonical. TODOs, half-specs, drift, WinSCP intake valve. Read on-demand when Trey drops a file there for the current session. Never cite as reference truth. Historical files in here may describe pre-fix state that's already been resolved in code.
5. **`ogz-ledger/`** = superseded archive. Don't read unless specifically pointed at.

The original mistake pattern: treating `ogz-meta/ledger/` forensic-trace and pre-fix audit docs as current state. Those docs describe the bug BEFORE the fix landed. Always verify the code still looks like the doc claims before asserting anything.
