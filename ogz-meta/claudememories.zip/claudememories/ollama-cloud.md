---
name: Ollama Cloud API Access
description: Ollama Cloud models available as external verification source — DeepSeek 671B + Qwen Coder 480B via REST API
type: reference
---

Ollama Cloud API is available for external model verification alongside Mercury-2.

**Endpoint:** `https://api.ollama.com/api/generate`
**Auth:** Bearer token via `OLLAMA_API_KEY` env var
**Key location:** `.env` file (`OLLAMA_API_KEY=...`)

**Available models (verified working 2026-04-14):**
- `deepseek-v3.1:671b-cloud` — DeepSeek V3.1 671B, ~595ms latency
- `qwen3-coder:480b-cloud` — Qwen 3 Coder 480B, 256K context, ~619ms latency
- `gpt-oss:120b-cloud` — OpenAI open-weights 120B (untested)

**Usage:** Free tier, light usage, 1 concurrent model, session limits reset every 5 hours. GPU-time based, no token caps. Prompt data never logged or trained on. Tool calling supported.

**CLI note:** `ollama run` CLI gives 401 on cloud models. Use REST API with Bearer auth instead.

**How to apply:** When Mercury produces a finding that needs independent verification, fire the same query at DeepSeek 671B or Qwen 480B via the REST API. Different model families = different reasoning biases = stronger convergence when they agree.

**Example curl:**
```bash
curl -s https://api.ollama.com/api/generate \
  -H "Authorization: Bearer $OLLAMA_API_KEY" \
  -d '{"model":"qwen3-coder:480b-cloud","prompt":"...","stream":false}'
```
