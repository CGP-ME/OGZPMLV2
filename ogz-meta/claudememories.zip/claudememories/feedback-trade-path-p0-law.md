---
name: Trade-path changes are P0 — Mercury attack every change, no bandaids, no deferment, one change = one commit
description: Hot-path code (core/, brokers/, modules/, run-empire-v2.js, anything that touches trade lifecycle) cannot ship as bandaid. Every change gets Mercury attack pass. Found-bug = fixed-bug, no "deferred to later batch" allowed. One change = one commit = one push.
type: feedback
originSessionId: a19c960d-8a89-41b1-8c1f-9d8a49816075
---
When a change touches the trade path (anything that affects trade lifecycle — candle ingestion through state mutation), the law is hard:

1. **P0 testing required** — full smoke test + backtest baseline check (`$18,497.278595001146 / 1,384 / 60.0% / 2.63% / 2.85` at this writing). If Phase 0 numbers drift, stop.
2. **Mercury attack pass on EVERY change** — adversarial framing per `feedback-mercury-attack-not-verify.md`. Not "is it correct?" — "find a state that lies, construct a crash, use this as a weapon."
3. **No bandaids** — if Mercury surfaces a finding on the fix, the fix is wrong. Don't ship 6a-style "real-but-architecturally-debt-laden" commits and document the debt for later.
4. **No deferment** — found problem = fixed problem. "Defer to post-X" / "schedule for batch Y" / "low priority follow-up" are violations. Severity is for ORDER not ship-vs-skip (per `feedback-no-deferred.md`).
5. **One change = one commit = one push** — never bundle multiple trade-path fixes into a single commit. Mercury verifies the diff, the commit lands alone, push immediately, then move to next (per `feedback-commit-hygiene.md`).

**Why:** Trade path is where capital lives. Every bandaid becomes a future $18k Phase 0 baseline corruption when the architectural debt compounds. The 6a saga (Mercury found 6 real findings on a bandaid that should have been a refactor) proved this in real time. Trey ratified the law 2026-05-11 after the DeepSearch audit (weresofucked.md) surfaced 12 more bugs riding on top of bandaid-class fixes that had been "documented as known issues" instead of resolved.

**Scope:**
- **In:** `core/**`, `brokers/**`, `modules/**`, `run-empire-v2.js`, anything called from the candle → strategy → exit → state mutation chain
- **Out:** Cognition infrastructure (`trai_brain/`, `tools/serena-bridge.js`), docs (`ogz-meta/`), configs, frontend (`frontend/`). Mercury attack still allowed/encouraged but not blocking-P0.

**How to apply:**
- Before touching trade path code: identify which Mercury attack prompt fits, draft it adversarially, hold it ready.
- After change: dispatch Mercury attack with file:line ranges (per `feedback-mercury-exact-line-ranges.md`), max-tokens=7750 (per `feedback-mercury-max-tokens.md`), one-at-a-time (per `feedback-mercury-one-at-a-time.md`).
- If Mercury returns findings: fix THEM, don't classify-down to "known debt." Each finding gets its own commit cycle.
- If Phase 0 baseline drifts even by a basis point: stop, re-baseline, investigate. The numbers are the gate.
- Commit messages reference: trade-path change + Mercury attack outcome + Phase 0 result.

**Adopted:** 2026-05-11 after DeepSearch audit surfaced 12 bugs (S7-BUG-1 through S12-BUG-2, P1-A through P6-C) that had been silently accumulating because prior fixes shipped as bandaids with debt deferred. Trey ratified: "if anything touches the trade path its p0 testing everything that gets changed get attacked by mercury there are no bandaids or deferrment if a problem arises we fix it one chagne one commit period."
