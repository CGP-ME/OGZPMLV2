---
name: Mercury Prompts Must Attack, Not Verify
description: Mercury is rarely wrong. When findings are soft, the cause is usually a verification-flavored prompt instead of an adversarial one. Always frame as "how does this break?" not "is this correct?"
type: feedback
originSessionId: 178e5620-a10e-4916-93d4-a046460eeb3c
---
**The pattern:** Mercury returns soft / advisory findings. I conclude "the code is mostly fine." Trey calls it out: Mercury is rarely wrong; the prompt was the issue.

**Diagnostic test:** look at the prompt's task wording. Verification framing reads:
- "Is every field present in every branch?"
- "Is the priority right?"
- "Are these equivalent?"
- "Is X correct / does it work as intended?"

Adversarial framing reads:
- "Find a state where this LIES."
- "Construct a sequence that CRASHES the consumer."
- "Find a CONCURRENT race that lands wrong."
- "Find a state where pre and post DIVERGE."
- "Use this as a WEAPON — show how it can be misused."

The adversarial framing puts Mercury in attack mode. It explicitly says "find breakages, not verifications." Mercury responds in kind — it tries to construct counterexamples instead of confirming claims.

**Empirical evidence (2026-04-27 session, recorded the night I learned this):**

| Audit | Prompt framing | Findings | Mercury verdict |
|---|---|---|---|
| C2 first attempt | Verification ("is the priority right?", "is every field present?") | 3 soft findings, MEDIUM/HIGH advisory | "FIX FIRST" but advisory only |
| C2 adversarial re-dispatch (same code) | Attack ("find a state where this LIES", "find the consumer crash") | 3 REAL bugs: 1 CRITICAL crash, 1 HIGH lying DEAD, 1 MEDIUM watchdog-fooler | All reproducible, all fixable, FIX FIRST |
| C1 | Verification ("are these equivalent?") | EQUIVALENT verdict | Suspicious — needs adversarial re-run |
| A original (ResilientWebSocket) | Mid-strength ("can it leak / race / spin") | 7 false-positives + 1 medium | Mid-confidence — worth re-running adversarial |
| B2, B3 | Adversarial framing ("is the guard defeated", "if disk fills up") | Real bugs found at appropriate severity | Solid |

The adversarial C2 dispatch found a CRITICAL consumer crash that any future supervisor consumer would have hit in production. The verification C2 missed it entirely.

**How to apply:** Before dispatching any Mercury audit, re-read the task wording. If any task starts with "is" / "are" / "does it" / "verify" — REWRITE it. Replace with imperative attack verbs: "find," "construct," "produce," "show that," "break."

**When verification framing IS appropriate:** post-fix re-audits explicitly verifying that a previously-found bug is now closed. "Verify each is now fixed" is correct framing because the bugs are already known and the question is closure-confirmation. Even then, follow up with a fresh adversarial pass if the component is critical-path.

**The damage of soft prompts:** "verified clean" verdicts on softball prompts give false confidence. The C2 first attempt's MEDIUM advisory could have shipped to production with the CRITICAL crash latent in the code, surfacing only when a future consumer dereferenced the null. That's exactly the failure mode Trey flagged: "Mercury is rarely wrong" — but it WAS the prompt that was wrong, and the false-clean signal nearly carried the bug forward.

**Linked memories:**
- feedback-teammates-not-targets — don't dunk on Mercury; my prompt is the variable
- feedback-mercury-exact-line-ranges — exact ranges + adversarial framing compound
- feedback-default-to-hard-path — verification is the easy framing; attack is the hard one
- feedback-transparent-audit-categorization — once Mercury finds bugs adversarially, categorize them honestly without severity-laundering
