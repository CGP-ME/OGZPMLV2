---
name: Don't Claim "Edge" From Invalid Tests
description: Trade jargon is fine generally, but don't claim edge/profitability when the test isn't apples-to-apples valid
type: feedback
originSessionId: 47aec99c-eb1d-4ad7-b253-8af46743572c
---

Trade jargon (edge, alpha, expectancy, R-multiple, etc.) is fine in conversation generally — Trey uses it himself. The rule is: don't apply that jargon to a backtest whose setup isn't valid for the claim.

**Why:** Trey called this out 2026-05-03 when I described AAPL backtest results in terms of "edge" while:
- Fees were Kraken crypto (0.65% round-trip), not Alpaca stocks (~$0)
- Strategy exit contracts were tuned for crypto volatility, not stocks
- NoWick wasn't firing despite obvious wickless candles in row 1 (real detection bug)
- P0 baseline was BTC, not stocks

His exact framing: "youre talking about edge on something that isnt fully setup or being tested correctly it makes no sense." The numbers existed but didn't mean what I framed them as. Calling that "edge" anchored a wrong conclusion.

**How to apply:** Before using performance jargon (edge / expectancy / PF / "the strat works"), check:
- Is the asset class right? (BTC results don't tell you about TSLA edge)
- Is the fee model real? (Kraken fees on Alpaca = ~1000x overcharge)
- Are the signals firing as designed? (Zero trades ≠ "doesn't work" ≠ "works")
- Is the comparison apples-to-apples? (BTC year vs AAPL 10mo isn't)

If any of those are no, describe what the data actually shows AND flag the validity gap before drawing a conclusion. "Strategies produced X net P&L on BTC with Kraken fees" is honest. "Strategies have edge" / "strategies are losing money" without flagging the setup mismatch is not.
