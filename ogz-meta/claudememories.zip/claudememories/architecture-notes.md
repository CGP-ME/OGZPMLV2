# OGZPrime Architecture Notes

## Data Flow (from mermaid charts)
```
Kraken WebSocket → CandleProcessor → TradingLoop → StrategyOrchestrator
  → ExitContractManager (if in position)
  → EntryDecider → EntryGateChecker → OrderExecutor (if signal found)
  → Dashboard WebSocket → ogzprime.com
```

## Symbol Format Chain (CRITICAL - Landmine!)
```
TradingConfig: "BTC-USD"
→ Kraken WS: "XBT/USD" (subscribe)
→ Kraken REST: "XXBTZUSD" (orders)
→ Display: "BTC-USD"
```
Never hardcode symbol formats. Use broker layer conversions.

## Key Files
- `run-empire-v2.js` - Main entry point
- `core/StrategyOrchestrator.js` - Winner-takes-all strategy evaluation
- `core/TradingConfig.js` - Single source of truth for params
- `core/ExitContractManager.js` - Exit logic (works well, don't touch)
- `modules/MADynamicSR.js` - 123 pattern strategy
- `modules/VolumeProfile.js` - POC/VAH/VAL/LVN chop filter
- `tuning/tuning-backtest-full.js` - Backtest runner

## Backtest Infrastructure
- `tuning/tuning-backtest-full.js` runs strategies against historical data
- `BacktestRecorder` tracks trades with running balance and fees
- CSV export for analysis
- Uses same StrategyOrchestrator as live (agnostic)

## Pipeline Rewrite Status (REWRITE-SPEC-FINAL.md)
- 6-phase plan to kill ~7,000 lines of dead code
- KILL list: OptimizedTradingBrain (3532 lines), SignalGenerator, ScalpSignalManager
- REWRITE list: MADynamicSR, TradingLoop, EntryDecider, EntryGateChecker
- Clean gates from 12+ to 3 entry / 9 exit
- Status: Spec written, execution in progress

## Known Landmines (from 05_landmines-and-gotchas.md)
- GIT_NUKE_001: Never git reset --hard
- SELL_ACCUMULATE_012: Sell signal + accumulate position = chaos
- WS_ZOMBIE_013: WebSocket reconnection must reset state
- TRAI_THINK_014: TRAI module has its own parallel brain
- TIMEFRAME_016: 15m candle aggregation timing matters
- WS_CONNECTED_017: krakenWs.isConnected is a method, not property
