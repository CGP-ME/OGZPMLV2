# Strategy Regime Filter Spec (Pending)

## Status: NOT YET APPLIED (shared by Trey for context on 2026-03-06)

## Concept
Split strategies into TREND vs CHOP lanes using VolumeProfile market state.

## Strategy Classification
```javascript
const TREND_STRATEGIES = ['MADynamicSR', 'EMASMACrossover'];
const CHOP_STRATEGIES = ['RSI', 'LiquiditySweep'];
```

## VP Market State Logic
- VP balanced market → `skipTrendStrategies = true` (allow CHOP only)
- VP trending/imbalanced → `skipChopStrategies = true` (allow TREND only)

## Additional Changes
- RSI thresholds widened from 25/75 to 35/65 for chop markets
- Applied in StrategyOrchestrator.js evaluation loop

## Backtest Plan (4 tests)
1. Baseline (current) - establish reference
2. Regime filter only - add VP lane filtering
3. Regime + RSI widening - add relaxed RSI thresholds
4. Full regime + cooldown tuning - final calibration

## File Changes
- `core/StrategyOrchestrator.js` - Add regime classification and filtering
- Strategy modules may need minor threshold adjustments
