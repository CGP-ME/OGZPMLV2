STOP 1 SOURCE EVIDENCE — 6ca25ae80cfcef12eec79e64c7d14162d9d4c751

Read STOP1-AUDIT-6ca25ae8.md first. Its findings, scope limits and source/event/runtime distinctions govern this evidence package.

This package contains generated audit inventories and exact historical source coordinates. It does not contain a replacement Git checkout, an accepted migration manifest or a live trading receipt.

- STOP1-ITEM-LEDGER.csv/json: 158 parent-assigned current disposition rows; 109 principal IDs plus explicit split/OPEN/obligation/dependency rows. Status refers to the named behavior or investigation obligation, not automatic authorization to execute historical instructions.
- STOP1-HISTORY-CLASSIFICATION.csv, ALIASES.csv, CANDIDATES.csv: 53 distinct source blobs, 101 aliases and 127 broad filename candidates. Duplicate copies are not independent evidence. Historical review assertions are not adopted conclusions.
- source-census/: frozen JSON/BASE/env/getter/constructor/dynamic source candidates and join methods. Field unresolved means unresolved. A source line or AST match is not a proven runtime consumer. The broad and narrow env counts have different selection boundaries, documented in stop1_environment_census_boundaries.*.
- lineage/: exact requirement occurrences, source IDs/hashes/aliases, manifest packet claims and authority quotation candidates. This is preserved evidence about historical claims, not an answer inherited from another reviewer.
- commit-index/: parent SHAs, changed paths and hunk coordinates; obtain source/diffs from the frozen Git repository. No historical test claim is a test run performed in this audit.

No bot boot, repository test, PM2 operation, broker/provider request, order, notification or financial outcome was obtained. Artifact checks only validate file consistency. Full semantic consumer/leaf clearance and all actionable-prose dispositions remain incomplete as stated in the report.
